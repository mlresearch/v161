# Variational Refinement for Importance Sampling Using the Forward Kullback-Leibler Divergence

Example code for running experiments for algorithms in
the paper "Variational Refinement for Importance Sampling Using the Forward Kullback-Leibler Divergence".

Run the following to install dependencies:
```shell
virtualenv -p python3 .
source ./bin/activate

pip3 install -r requirements.txt
```

Additional dependencies:
https://github.com/andymiller/vboost/blob/master/code/vbproj/models/uci.py
and
https://github.com/andymiller/vboost/blob/master/code/vbproj/models/nn.py

Run the following for the FKL boosting experiments.
```shell
python3 -m run_blr_ais -- --reverse_value=False --remainder_value=False
```

Run the following for the RKL boosting experiments.
```shell
python3 -m run_blr_ais -- --reverse_value=True --remainder_value=False
```
