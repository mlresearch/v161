# UAI 2021 submission

- [UAI 2021 submission](#uai-2021-submission)
  * [Outline](#outline)
  * [Installation](#installation)
    + [Dependancies](#dependancies)
      - [Additional tools](#additional-tools)
      - [Compile AFK-MC² implementation](#compile-afk-mc--implementation)
      - [Compile KMeans++ implementation](#compile-kmeans---implementation)
    + [Data](#data)

## Outline

There are two notebooks to reproduce the results: `ALGORITHM{1,2}_simulations.ipynb`, for each algorithm considered in the paper. An `html` version is available for a visual check.

## Installation

### Dependancies

Create the environment from the environment.yml file:

```commandline
conda env create -f environment.yml
```

Activate the new environment: `conda activate uai`.

Verify that the new environment was installed correctly:

```commandline
conda env list
```

#### Additional tools

##### Vose-Alias sampling

Need an implementation of Vose-Alias sampling for efficient sampling of discrete distributions. Credits to **MaxHalford**.

```commandline
pip install git+https://github.com/MaxHalford/vose.git
```

##### `clustering` package

Need a few clustering algorithms (which were actually developed a bit later -- this is redundant, and will be taken care of later on) for algorithm 2. Go to the `clustering` directory, and run `pip install .`. This requires you to have `Pybind` and `Eigen` downloaded on your PC. Refer to  `clustering/README.md` for detailed help.

#### Compile AFK-MC² implementation

This was coded with Cython. 

```commandline
cd vose_mc_kmeans
python setup.py build_ext --inplace
cd ..
```

#### Compile KMeans++ implementation
This was coded with Cython too. 

```commandline
cd kmeanspp
python setup.py build_ext --inplace
cd ..
```

### Data

Download the `DOT` and `adult` dataset in `data`:
```commandline
wget -O data/adult/adult.data https://archive.ics.uci.edu/ml/machine-learning-databases/adult/adult.data
wget -O data/DOT/dot.zip http://www.stochastik.math.uni-goettingen.de/DOTmark_1.0.zip
unzip -q data/DOT/dot.zip -d data/DOT/
```

