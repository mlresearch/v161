# AFK-MC^2

## Install

### Vose sampler
Need Vose Sampler implementation of MaxHalford. You can download it with:

```commandline
pip install git+https://github.com/MaxHalford/vose.git
```
`cimport vose` is now available. 

### Other libraries

Cython, numpy. 

### Compile

Use `python setup.py build_ext --inplace`.
