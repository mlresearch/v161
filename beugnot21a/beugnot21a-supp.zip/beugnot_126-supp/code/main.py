# from vose_mc_kmeans.mc_kmeans import kmc2
# from kmeanspp.kmeansinplace import kmeansinplace_init_greedy
import numpy as np
from plot_utils import random_points_circle
from estimate_ot.distribution.distribution import ContinuousDistribution, FiniteDistribution
import matplotlib.pyplot as plt

# kmc2(np.random.random((10, 2)), 4, 10)
# kmeansinplace_init_greedy(np.random.random_sample((10, 2)), np.zeros(10, dtype='int32'), 3, 2)

tau = 1e-2
mu_alpha = random_points_circle(3, .1)
mu_beta = random_points_circle(5, 1)

alpha = ContinuousDistribution.gaussian_mixture(np.ones(3)/3, mu_alpha, np.stack([np.eye(2)*tau]*3))
beta = ContinuousDistribution.gaussian_mixture(np.ones(5)/5, mu_beta, np.stack([np.eye(2)*tau]*5))

fig, ax = plt.subplots()
alpha.plot(30, ax=ax)
beta.plot(30, ax=ax)