import numpy as np
from matplotlib import pyplot as plt
from sklearn.linear_model import LinearRegression
from matplotlib.font_manager import FontProperties
import seaborn as sns
import pandas as pd


def scatter_points_and_anchors(X, labels, anchors, scatter_arg, plot_arg, ax=None):
    if ax is None:
        ax = plt.gca()
    ax: plt.Axes

    for p, l in zip(X, labels):
        ax.scatter(*p, **scatter_arg)
        ax.plot(*zip(p, anchors[l]), **plot_arg)

    return ax


def add_linear_regression(ax=None, custom_label=None, skip_first_quantile=0):
    """
    Parameters
    ----------
    ax:
        Matplotlib Axes on which to add the legend
    custom_label:
        Seaborn has a really messy way of handling line labels. Pass a custom list of labels here.
    """
    if ax is None:
        ax = plt.gca()
    ax: plt.Axes

    for i, line in enumerate(ax.get_lines()):
        line: Line2D

        x, y = line.get_data()
        sorted_x = np.argsort(x)
        x, y = x[sorted_x], y[sorted_x]
        if skip_first_quantile != 0:
            q = skip_first_quantile
            x = x[int(x.shape[0] * q):]
            y = y[int(y.shape[0] * q):]

        if x.size == 0 or y.size == 0:
            # This line is empty, probably seaborn great handling
            continue

        color = line.get_color()
        if custom_label is None:
            label = line.get_label()
        else:
            label = custom_label[i]

        if ax.get_xscale() == 'log':
            x = np.log10(x)
        if ax.get_yscale() == 'log':
            y = np.log10(y)
        model = LinearRegression()
        model.fit(x.reshape(-1, 1), y)
        coef, intercept = model.coef_[0], model.intercept_
        linear_regression = lambda x: x * coef + intercept
        x_start, x_end = x[0], x[-1]
        y_start, y_end = linear_regression(x_start), linear_regression(x_end)

        if ax.get_xscale() == 'log':
            x_start, x_end = 10 ** x_start, 10 ** x_end
        if ax.get_yscale() == 'log':
            y_start, y_end = 10 ** y_start, 10 ** y_end
        ax.plot([x_start, x_end], [y_start, y_end], color=color, linestyle='-.', alpha=.2,
                label=f'reg_{label}: {coef:.2f}x + {intercept:.2f}')
    return


font_labels = FontProperties()
font_labels.set_family('lmodern')
# font_labels.set_name('Times New Roman')
# font_labels.set_style('italic')
size = 16
font_labels.set_size = size
FONTSIZE_LEGEND = size
plt.rcParams['ytick.left'] = True
plt.rcParams['xtick.bottom'] = True
from matplotlib.lines import Line2D

CMAPS_SEQUENTIAL = sns.color_palette('muted')
for i, j in zip([0, 1, 2, 3], [1, 2, 0, 3]):
    CMAPS_SEQUENTIAL[i] = sns.color_palette('muted')[j]


def _result_to_ax(df, hue, x, y, quantile, ax, xylabels, hue_color, hue_names, ci):
    return_values = {}
    if ci:
        sns.lineplot(x, y, data=df, hue=hue, palette=hue_color, ci=95, ax=ax, marker='o', markeredgecolor=None,
                     legend=False)
    for label, group in df.groupby(hue):
        groupby = group.groupby(x)[y]
        result = pd.concat([groupby.mean(), groupby.std()], axis=1, keys=['y', 'y_err'])
        result = result.reset_index().rename({x: 'x'}, axis=1)

        # Regression line
        start_x = np.quantile(group[x].unique(), q=quantile, interpolation='lower')
        X_reg = result[result['x'] > start_x]['x'].values.reshape(-1, 1)
        Y_reg = result[result['x'] > start_x]['y']
        X_reg, Y_reg = np.log10(X_reg), np.log10(Y_reg)

        model = LinearRegression()
        model.fit(X_reg, Y_reg)

        result['y_reg'] = 10 ** model.predict(np.log10(result['x'].values.reshape(-1, 1)))

        # Plots
        ax.plot(result['x'], result['y'], c=hue_color[label], linestyle='-', marker='o',
                label=f'{hue_names[label]} (-{-model.coef_.item():.2f})',  # fontproperties=font_legend
                )

        ax.plot(result['x'], result['y_reg'], c=hue_color[label], linestyle='-.', alpha=.5)

        ax.set_xscale('log')
        ax.set_yscale('log')
        ax.set_xlabel(xylabels[0], fontproperties=font_labels)
        ax.set_ylabel(xylabels[1], fontproperties=font_labels)
        for tick in ax.xaxis.get_major_ticks() + ax.yaxis.get_major_ticks():
            tick.label.set_fontsize(size)

        ax.legend(fontsize=FONTSIZE_LEGEND)

        return_values[label] = result
    return ax, return_values


def result_to_axes(df, hue, x, y, quantile=0, axes=None, groupby_id=None, xylabels=None, hue_color=None, hue_names=None,
                   ci=False):
    if hue_color is None:
        hue_color = {n: c for n, c in zip(df[hue].unique(), CMAPS_SEQUENTIAL)}
    if xylabels is None:
        if (x, y) == ('samples', 'rel_bias'):
            xylabels = '$k$', 'Mean Relative Error'
        else:
            xylabels = x, y
    if hue_names is None:
        hue_names = {n: n for n in df[hue].unique()}
    if groupby_id is None:
        if axes is None:
            axes = plt.gca()
        return _result_to_ax(df, hue, x, y, quantile=quantile, ax=axes, xylabels=xylabels, hue_color=hue_color,
                             hue_names=hue_names, ci=ci)

    result = {}
    for (label, group), ax in zip(df.groupby(groupby_id), axes):
        result[label] = _result_to_ax(group, hue, x, y, quantile=quantile, ax=ax, xylabels=xylabels,
                                      hue_color=hue_color, hue_names=hue_names, ci=ci)
    return result


def savefig(fig, save_dir, name='results.pdf'):
    fig.set_size_inches(7, 4)
    fig.tight_layout()
    path = save_dir / name
    fig.savefig(path)  # , bbox_inches='tight', pad_inches=0)
    print(f'Saved to: {path}')

def random_points_circle(n_points, radius, dim=2):
    """Generate random points on a circle. Dim > 2 is uniform noise."""
    x = np.random.random(n_points, dim)
    x[:, 0] *= radius
    x[:, 1] *= 2 * np.pi
    x[:, 0], x[:, 1] = x[:, 0] * np.cos(x[:, 1]), x[:, 0] * np.sin(x[:, 1])
    return x 