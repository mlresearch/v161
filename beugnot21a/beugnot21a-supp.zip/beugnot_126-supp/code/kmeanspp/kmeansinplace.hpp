#ifndef __KMEANSINPLACE_H_
#define __KMEANSINPLACE_H_

#include <random>
#include <vector>
#include <cstring>
#include <algorithm>
#include <iostream>
#include <math.h>       /* log */
#include <cmath>        /* std::abs */


inline double dist2(const double *p1, const double *p2, int length) {
	double result = 0;
	for (int i = 0; i < length; i++) {
		result += (*p1 - *p2)*(*p1 - *p2); 
		p1++;
		p2++;
	}
	return result; 
}


inline double dist1(const double *p1, const double *p2, int length) {
	double result = 0;
	for (int i = 0; i < length; i++) {
		result += std::abs (*p1 - *p2);
		p1++;
		p2++;
	}
	return result;
}


void kmeans_c(double *points, int m, int n, int *result, int k) {
	std::vector<int> choice(k, 0);

    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> distrib(0, m-1);

    choice[0] = distrib(gen);

	std::fill_n(result, m, choice[0]); // fancy initialization
	
    std::vector<double> dists(m); // Justin doesn't like this --- it's a large malloc!

	#pragma omp parallel for
    for (int j = 0; j < m; ++j) dists[j] = dist2(points + n*j, points + n*choice[0], n);
    

    for (int i = 1; i < k; ++i) {
		std::discrete_distribution<int> weighted(dists.begin(), dists.end()); // note this isn't parallel...
		choice[i] = weighted(gen);

		#pragma omp parallel for
		for (int j = 0; j < m; ++j) {
			double norm = dist2(points + n*j, points + n*choice[i], n);
			if (norm < dists[j]){
				result[j] = choice[i];
				dists[j] = norm;
			}
		}
    }
}

void kmeans_greedy_c(double *points, int m, int n, int *result, int k) {
	std::vector<int> choice(k, 0);

    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> distrib(0, m-1);

    choice[0] = distrib(gen);

	std::fill_n(result, m, choice[0]); // fancy initialization

    std::vector<double> dists(m); // Justin doesn't like this --- it's a large malloc!
    std::vector<double> dists_candidate(m); // distance to first candidate
    std::vector<double> dists_candidate_other(m); // distance to other candidate

    std::vector<int> assigned_candidate(m); // assignment to candidate
    std::vector<int> assigned_candidate_other(m);

    int n_candidates = 2 + int (log(k + 1));
    double inertia = 0, inertia_other = 0;
    int id_candidate;

	#pragma omp parallel for
    for (int j = 0; j < m; ++j) dists[j] = dist2(points + n*j, points + n*choice[0], n);


    for (int i = 1; i < k; ++i) {
		std::discrete_distribution<int> weighted(dists.begin(), dists.end()); // note this isn't parallel...
        inertia = 0;
		choice[i] = weighted(gen); // Choose first candidate
		for (int j = 0; j < m; ++j) assigned_candidate[j] = result[j];
		for (int j = 0; j < m; ++j) dists_candidate[j] = dists[j];

        // Could instead compute inertia to all candidates in parallel; but would be costly in memory?
		#pragma omp parallel for
		for (int j = 0; j < m; ++j) { // Inertia and distance to the first candidate
			double norm = dist2(points + n*j, points + n*choice[i], n);
			if (norm < dists[j]){
				assigned_candidate[j] = choice[i];
				dists_candidate[j] = norm;
			}
			inertia += dists_candidate[j];
		}

        for (int c = 1; c < n_candidates; ++c) { // Inertia to new candidate
            inertia_other = 0;
            id_candidate = weighted(gen); // sample a candidate
            for (int j = 0; j < m; ++j) assigned_candidate_other[j] = result[j];
            for (int j = 0; j < m; ++j) dists_candidate_other[j] = dists[j];

            #pragma omp parallel for
            for (int j = 0; j < m; ++j) {
                double norm = dist2(points + n*j, points + n*id_candidate, n);
                if (norm < dists[j]){
                    assigned_candidate_other[j] = id_candidate;
                    dists_candidate_other[j] = norm;
                }
                inertia_other += dists_candidate_other[j];
            }

            if (inertia_other < inertia) {
                inertia = inertia_other;
                dists_candidate = dists_candidate_other;
                assigned_candidate = assigned_candidate_other;
                choice[i] = id_candidate;
            }
		}

		// Update values with the best candidate
		for (int j = 0; j < m; ++j) result[j] = assigned_candidate[j];
		dists = dists_candidate;
    }
}


// TODO: make a single function, with non-type template parameter
void kmeans_greedy_c_norm1(double *points, int m, int n, int *result, int k) {
	std::vector<int> choice(k, 0);

    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> distrib(0, m-1);

    choice[0] = distrib(gen);

	std::fill_n(result, m, choice[0]); // fancy initialization

    std::vector<double> dists(m); // Justin doesn't like this --- it's a large malloc!
    std::vector<double> dists_candidate(m); // distance to first candidate
    std::vector<double> dists_candidate_other(m); // distance to other candidate

    std::vector<int> assigned_candidate(m); // assignment to candidate
    std::vector<int> assigned_candidate_other(m);

    int n_candidates = 2 + int (log(k + 1));
    double inertia = 0, inertia_other = 0;
    int id_candidate;

	#pragma omp parallel for
    for (int j = 0; j < m; ++j) dists[j] = dist1(points + n*j, points + n*choice[0], n);


    for (int i = 1; i < k; ++i) {
		std::discrete_distribution<int> weighted(dists.begin(), dists.end()); // note this isn't parallel...
        inertia = 0;
		choice[i] = weighted(gen); // Choose first candidate
		for (int j = 0; j < m; ++j) assigned_candidate[j] = result[j];
		for (int j = 0; j < m; ++j) dists_candidate[j] = dists[j];

        // Could instead compute inertia to all candidates in parallel; but would be costly in memory?
		#pragma omp parallel for
		for (int j = 0; j < m; ++j) { // Inertia and distance to the first candidate
			double norm = dist1(points + n*j, points + n*choice[i], n);
			if (norm < dists[j]){
				assigned_candidate[j] = choice[i];
				dists_candidate[j] = norm;
			}
			inertia += dists_candidate[j];
		}

        for (int c = 1; c < n_candidates; ++c) { // Inertia to new candidate
            inertia_other = 0;
            id_candidate = weighted(gen); // sample a candidate
            for (int j = 0; j < m; ++j) assigned_candidate_other[j] = result[j];
            for (int j = 0; j < m; ++j) dists_candidate_other[j] = dists[j];

            #pragma omp parallel for
            for (int j = 0; j < m; ++j) {
                double norm = dist1(points + n*j, points + n*id_candidate, n);
                if (norm < dists[j]){
                    assigned_candidate_other[j] = id_candidate;
                    dists_candidate_other[j] = norm;
                }
                inertia_other += dists_candidate_other[j];
            }

            if (inertia_other < inertia) {
                inertia = inertia_other;
                dists_candidate = dists_candidate_other;
                assigned_candidate = assigned_candidate_other;
                choice[i] = id_candidate;
            }
		}

		// Update values with the best candidate
		for (int j = 0; j < m; ++j) result[j] = assigned_candidate[j];
		dists = dists_candidate;
    }
}


#endif // __KMEANSINPLACE_H_