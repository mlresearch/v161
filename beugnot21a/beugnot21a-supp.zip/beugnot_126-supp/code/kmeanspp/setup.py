from distutils.core import setup

import numpy
from Cython.Build import cythonize
from setuptools import Extension

ext_modules = [Extension("kmeansinplace", ["kmeansinplace.pyx"],
                         extra_compile_args=['-fopenmp', '-O3', '-Ofast', '-funsafe-math-optimizations',
                                             '-fassociative-math', '-freciprocal-math', '-ffast-math', '-g0'],
                         extra_link_args=['-fopenmp'])]

setup(ext_modules=cythonize(ext_modules), include_dirs=[numpy.get_include()])
