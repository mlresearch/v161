import numpy as np

from vose_mc_kmeans.mc_kmeans import kmc2
from kmeanspp.kmeansinplace import kmeansinplace_init_greedy


def _2dim_array(arr):
    if arr.ndim != 2:
        raise ValueError(f"Your point cloud must be 2-dim (n_point, n_dim). Got shape: {arr.shape}.")


def assumption_free_kmc2(X: np.ndarray, n_clusters: int, m: int):
    _2dim_array(X)

    if X.shape[0] == 1:
        # Avoid division by 0
        return np.concatenate([X]*n_clusters)

    clusters = kmc2(X, n_clusters, m)

    # The algorithm can return the same cluster multiple times. Let's prevent that.
    clusters = np.unique(clusters, axis=0)
    return clusters


def kmeans_init(X, n_clusters, norm=2):
    _2dim_array(X)
    n, d = X.shape
    assigned = np.zeros(n, dtype='int32', order='C')
    kmeansinplace_init_greedy(X, assigned, n_clusters, norm=norm)
    anchors, weights = np.unique(assigned, return_counts=True)
    return X[anchors], weights