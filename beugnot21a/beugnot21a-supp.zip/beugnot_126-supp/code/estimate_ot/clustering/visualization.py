import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
from tqdm import tqdm

from .clustering import kmeans_init, IncrementalKCenter, assumption_free_kmc2
from .utils import coreset_quality


def plot_random_kmeans(n=10, c=2, m=10):
    import matplotlib.pyplot as plt

    X = np.random.random((n, 2))
    clusters_kmeans, weights_kmeans = kmeans_init(X, c)
    clusters_afk, weights_afk = assumption_free_kmc2(X, c, m)

    fig, ax = plt.subplots()
    ax: plt.Axes

    ax.scatter(X[:, 0], X[:, 1], marker='+', color='k')
    for order, (c, s) in enumerate(zip(clusters_kmeans, weights_kmeans)):
        ax.scatter(c[0], c[1], marker='o', color='r', alpha=.5)
        # ax.text(c[0], c[1], s=f"{order}: {s}")

    for order, (c, s) in enumerate(zip(clusters_afk, weights_afk)):
        ax.scatter(c[0], c[1], marker='o', color='b', alpha=.5)


def plot_kmeans_repartition():
    n = 100
    n_clusters = 10
    # X = np.random.random_sample((n, 2))
    X = np.random.multivariate_normal(mean=np.zeros(2), cov=np.eye(2),
                                      size=n)

    cluster_quality = np.zeros((n, 3))
    cluster_result = np.zeros((n, n_clusters, 2))
    for i in range(n):
        rolled_X = np.roll(X, i, axis=0)
        centroids, _ = kmeans_init(rolled_X, n_clusters, deterministic=True)
        cluster_quality[i] = coreset_quality(rolled_X, centroids)
        cluster_result[i] = centroids

    fig, axes = plt.subplots(1, 3)
    for i, (ax, name) in enumerate(zip(axes, ['delta', 'inertia', 'entropy'])):
        ax: plt.Axes
        sns.distplot(cluster_quality[:, i], ax=ax)
        ax.set_title(name)
    fig.suptitle('Repartition of various metric evaluating the quality of a coreset.')

    n_best = 2
    fig_c, axes_c = plt.subplots(n_best+1, 3)

    results_best = np.argsort(cluster_quality, axis=0)[:n_best, :]
    for i in range(n_best):
        for j, name in enumerate(['delta', 'inertia', 'entropy']):
            id_best = results_best[i, j]
            ax = axes_c[i, j]
            ax: plt.Axes
            ax.set_aspect('equal')
            ax.tick_params(labelbottom=False, labelleft=False)
            # Show point cloud
            ax.scatter(X[:, 0], X[:, 1], c='b', marker='o')
            # Display best on top
            ax.scatter(cluster_result[id_best][:, 0], cluster_result[id_best][:, 1],
                       c='r', marker='o')
            # Show its name and quality metric
            ax.set_title(f'{name} = {cluster_quality[id_best, j]:.2f} ({id_best})')

    results_worst = np.argsort(cluster_quality, axis=0)[-1, :]
    for j, name in enumerate(['delta', 'inertia', 'entropy']):
        id_worst = results_worst[j]
        ax = axes_c[-1, j]
        ax: plt.Axes
        ax.set_aspect('equal')
        ax.tick_params(labelbottom=False, labelleft=False)
        # Show point cloud
        ax.scatter(X[:, 0], X[:, 1], c='b', marker='o')
        # Display best on top
        ax.scatter(cluster_result[id_worst][:, 0], cluster_result[id_worst][:, 1], c='r', marker='o')
        # Show its name and quality metric
        ax.set_title(f'{name} = {cluster_quality[id_worst, j]:.2f} ({id_worst})')

    return X, cluster_quality, cluster_result


def plot_incremental(animation=False):
    """Plot an example of IncrementalKCenter."""
    # Uniform
    # sampler = lambda n: np.random.uniform(size=(n, 2))
    # Gaussian
    sampler = lambda n: np.random.multivariate_normal(np.zeros(2), np.eye(2), size=n)

    n_clusters = 10
    n_total = 1000

    incremental_clusters = IncrementalKCenter(sampler(n_clusters))
    cluster_history = np.zeros((n_total-n_clusters, n_clusters, 2))
    all_points = np.zeros((n_total, 2))
    all_points[:n_clusters] = incremental_clusters.cluster.copy()

    for i in tqdm(range(n_total-n_clusters)):
        new_point = sampler(1)[0]
        incremental_clusters.add(new_point)
        cluster_history[i] = incremental_clusters.cluster.copy()
        all_points[n_clusters+i] = new_point.copy()

    fig, ax = plt.subplots()
    l_points, = ax.plot(*all_points.T, c='k', marker='+', alpha=.5, linestyle="")
    l_anchors, = ax.plot(*cluster_history[-1].T, c='r', marker='o', linestyle="")

    from matplotlib.widgets import Slider
    ax_slider = plt.axes([0.25, 0.1, 0.65, 0.03])
    slider = Slider(ax_slider, label="step", valmin=n_clusters, valmax=n_total, valstep=1,
                    valinit=10, valfmt='%d')

    def update(x):
        step = int(slider.val)
        l_points.set_data(*all_points[:step, :].T)
        l_anchors.set_data(*cluster_history[step-n_clusters-1].T)

    slider.on_changed(update)

    if animation:
        from matplotlib.animation import FuncAnimation
        ani = FuncAnimation(fig, lambda x: slider.set_val(x), frames=np.arange(n_clusters, n_total),
                            )
        return ax, slider, ani

    return ax, slider