import numpy as np
from scipy.spatial.distance import cdist


def anchor_assignment(X=None, anchors=None, distance_to_clusters=None):
    """Returns the label of the closest anchor for each data point."""
    if distance_to_clusters is None:
        assert (X is not None) and (anchors is not None)
        distance_to_clusters = cdist(X, anchors, metric='sqeuclidean')
    labels = np.argmin(distance_to_clusters, axis=1)
    return labels


def anchor_weights(X=None, anchors=None, distance_to_clusters=None):
    """"Returns the weight of each anchor."""
    labels = anchor_assignment(X, anchors, distance_to_clusters)
    unique, weights = np.unique(labels, return_counts=True)
    n_anchors = anchors.shape[0]
    # If an anchor has 0 point, must handle
    if unique.size != n_anchors:
        weights_padded = np.zeros(n_anchors)
        weights_padded[unique] = weights
        weights = weights_padded
    weights = weights / np.sum(weights)
    assert weights.shape[0] == n_anchors
    return weights


def coreset_quality(X, anchors):
    """Computes metrics on the quality of a coreset. Lower is better."""
    distance_to_anchors = cdist(X, anchors, metric='sqeuclidean')
    min_distance_to_anchors = np.min(distance_to_anchors, axis=1)

    # Furthest point from its cluster
    delta = np.max(min_distance_to_anchors)

    # Inertia
    inertia = np.sum(min_distance_to_anchors)

    # Discrepancy
    labels = np.argmin(distance_to_anchors, axis=1)
    weights = np.unique(labels, return_counts=True)[1]
    weights = weights / np.sum(weights)
    with np.errstate(divide='ignore', invalid='ignore'):
        entropy = - np.nansum(weights * np.log(weights))

    return delta, inertia, -entropy


def center_cluster(arr, labels):
    """For a point cloud where each point has a label, computes the corresponding centroids."""
    unique = np.unique(labels)
    n_unique = len(unique)
    dim = arr.shape[1]
    result = np.zeros((n_unique, dim))
    for i in range(n_unique):
        i_ = labels == unique[i]
        result[i] = np.sum(arr[i_], axis=0) / np.sum(i_)
    return result


def sqeuclidean_distance(x_1: np.ndarray, x_2: np.ndarray, squared_1=None):
    """Squared euclidean distance between two point clouds. Possibility to pass precomputed squares as input."""
    assert x_1.ndim == x_2.ndim == 2
    assert x_2.shape[1] == x_2.shape[1]

    if squared_1 is None:
        squared_1 = np.sum(x_1 ** 2, 1).reshape(-1, 1)
    squared_2 = np.sum(x_2 ** 2, 1).reshape(1, -1)
    return squared_1 + squared_2 - 2 * np.dot(x_1, x_2.T)