import itertools
from time import time
from typing import Iterable, Tuple

import pandas as pd
import numpy as np
from tqdm.auto import tqdm

from estimate_ot.estimate_ot import EstimateOT


def benchmark_ot(model: EstimateOT, values_to_try, n_batch, sqrt_cost=True, **kwargs):
    assert isinstance(model, EstimateOT)
    if np.max(np.unique(values_to_try, return_counts=True)[1]) > 1:
        raise ValueError("The values you pass are not unique. Can't do the benchmark. Use np.unique().")

    exponent = 1/2 if sqrt_cost else 1

    result = pd.DataFrame(columns=pd.Index(range(n_batch), name="run"),
                          index=pd.MultiIndex.from_product([values_to_try, ['t_fit', 't_tot', 'cost']],
                                                           names=['samples', "var"]), dtype='float32')

    for val, i in tqdm(itertools.product(values_to_try, range(n_batch)), total=len(values_to_try) * n_batch):
        t_execution = time()
        run_i = model.evaluate(val, n_runs=1, log=True, **kwargs)
        t_execution = time() - t_execution
        result.loc[(val, ['t_fit', 't_tot', 'cost']), i] = [run_i.t_run, t_execution, run_i.transport_cost ** exponent]
    return result


def join_benchmarks(method_param_df: Iterable[Tuple[str, pd.DataFrame]],
                    t_optimal: float = None, optimal_cost: float = None):
    """
    Join benchmarks of each result.

    Parameters
    ----------
    method_param_df:
        Iterable. Each element must be a tuple of name_of_the_method, df_of_the_results.
    t_optimal:
        Time to compute the optimal solution.
    optimal_cost:
        Cost of the optimal solution.
    """
    result = []
    for method, df in method_param_df:
        df = df.stack().reset_index(name='value')
        df['method'] = method
        df['value'] = df['value'].astype('float32')
        result.append(df.copy())
    result = pd.concat(result)
    result['value'] = result['value'].astype('float32')
    result = result.pivot_table(index=['method', 'samples', 'run'], columns='var', values='value')
    result = result.reset_index()
    if t_optimal is not None:
        result['f_tot'] = result['t_tot'] / t_optimal
    if optimal_cost is not None:
        result['bias'] = np.abs(result['cost'] - optimal_cost)
        result['rel_bias'] = result['bias'] / optimal_cost
    return result