import warnings
from collections import namedtuple
from functools import partial
from time import time

from ot.lp import emd as ot_emd
from ot.bregman import sinkhorn as ot_sinkhorn
import numpy as np

EMDOutput = namedtuple('EMDOutput', ['transport_plan', 'transport_cost', 'u', 'v', 'duality_gap', 't_run'])
EMDInput = namedtuple('EMDInput', ['weights_a', 'weights_b', 'cost_matrix'])

def _check_dim(a: np.ndarray, b: np.ndarray, cost: np.ndarray):
    if not a.ndim == b.ndim == 1:
        raise ValueError(f"Weights must be 1d array. Got: {a.ndim, b.ndim}.")
    if not cost.ndim == 2:
        raise ValueError(f"Cost must be 2d array. Got: {cost.ndim}.")
    if cost.shape != (a.size, b.size):
        raise ValueError(f"Unappropriate dimension. Weights have size: {a.size, b.size}, "
                         f"but cost matrix has shape: {cost.shape}.")


def emd(a, b, cost_matrix, numItermax=int(1e5)):
    """Wrapper around emd function of ot.lp in order to compute the duality gap automatically."""
    # Shape input check is not done in ot_emd
    _check_dim(a, b, cost_matrix)

    t_run = time()
    transport_plan, emd_output = ot_emd(a, b, cost_matrix, numItermax=numItermax, log=True)
    duality_gap = emd_output['cost'] - (emd_output['u'].dot(a) + emd_output['v'].dot(b))
    t_run = time() - t_run

    result = EMDOutput(transport_plan, emd_output['cost'], emd_output['u'], emd_output['v'], duality_gap, t_run)

    return result


def sinkhorn(a, b, cost_matrix, eps):
    """Wrapper around sinkhorn function of ot in order to compute the duality gap automatically."""
    _check_dim(a, b, cost_matrix)

    t_run = time()
    transport_plan, log = ot_sinkhorn(a, b, cost_matrix, eps, method='sinkhorn', log=True)
    gibbs_matrix = np.exp(- cost_matrix / eps)
    u, v = log['u'], log['v']
    f, g = eps * np.log(u), eps * np.log(v)
    dual_max = np.dot(f, a) + np.dot(g, b) - eps * np.dot(u, np.dot(gibbs_matrix, v))
    transport_cost = np.einsum('ik,ij,jk,ij->k', u.reshape(-1, 1), gibbs_matrix, v.reshape(-1, 1), cost_matrix).item()
    primal_min = transport_cost + eps * np.sum(transport_plan * (np.log(transport_plan) - 1))
    duality_gap = primal_min - dual_max
    t_run = time() - t_run

    result = EMDOutput(transport_plan, transport_cost, u, v, duality_gap, t_run)

    return result


def aggregate_output_divergence(ab: EMDOutput, aa: EMDOutput, bb:EMDOutput):
    """Turns 3 EMDOutput into a single one, when delaing with divergences."""
    transport_plan = None
    transport_cost = ab.transport_cost - .5 * (aa.transport_cost + bb.transport_cost)
    u, v = None, None
    duality_gap = max(map(lambda x: x.duality_gap, (aa, ab, bb)))
    t_run = ab.t_run + bb.t_run + aa.t_run
    return EMDOutput(transport_plan=transport_plan, transport_cost=transport_cost,
                     u=u, v=v, duality_gap=duality_gap, t_run=t_run)


