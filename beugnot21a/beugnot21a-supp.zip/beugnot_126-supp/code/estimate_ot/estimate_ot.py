from abc import ABC, abstractmethod
from functools import partial
from typing import Union, List, Type

import matplotlib.pyplot as plt
import numpy as np
from scipy.spatial.distance import cdist
from sklearn.cluster import KMeans as SklearnKMeans
from sklearn.cluster import MiniBatchKMeans as SklearnMiniKMeans

from .clustering.clustering import kmeans_init, assumption_free_kmc2
from .clustering.utils import anchor_weights
from .distribution.distribution import Distribution
from .utils import emd, EMDOutput, sinkhorn

# TODO: add docstrings to classes


class EstimateOT(ABC):
    """
    This class is used to estimate OT between two distribution. It means that each instanciation is specific to two
    distributions we wish to sample from. We can make the behaviour of the estimator change at runtime,
    but if we want to use it to estimate OT between other distribution, we must create a new instance.

    If strategies are recurrent in the preprocessing step, create abstract subclasses.

    Examples
    --------
    class CoupleEstimateOT(EstimateOT, ABC):
        def stacked(...):
            stacked_xy = ...
    """

    def __init__(self, alpha: Distribution, beta: Distribution, metric_norm=2,
                 prefactor_sampling=1.):
        """Estimate OT cost between two distributions."""
        if not alpha.has_same_dim(beta):
            raise ValueError("Distributions alpha and beta do not seem to live in the same dimension.")
        self.alpha = alpha
        self.beta = beta
        self.prefactor_sampling = prefactor_sampling

        if metric_norm == 2:
            self.metric = partial(cdist, metric="sqeuclidean")
            self.norm = metric_norm
        elif metric_norm == 1:
            self.metric = partial(cdist, metric="cityblock")
            self.norm = metric_norm
        else:
            raise NotImplementedError(f"Metric != [1, 2] is not currently supported. Got {metric_norm}.")

        # We can set the optimal cost in this variable, if it's known
        self.optimal_cost = None

    @abstractmethod
    def _generate_anchors(self, n: int, *args, **kwargs):
        """Generate n anchors."""
        pass

    @abstractmethod
    def _process_anchors(self, *args, **kwargs):
        """
        Process anchors.

        Returns
        -------
        histograms (for alpha and beta) and cost matrix, which will be passed to a LP solver.
        """
        pass

    @abstractmethod
    def _transport_cost(self, *args, **kwargs) -> EMDOutput:
        """Runs the LP solver.
        """
        pass

    def _evaluate(self, n: int, **kwargs):
        """Basic mechanism: choose anchors, preprocess, then compute OT on histograms."""
        anchors = self._generate_anchors(n, **kwargs)
        processed_anchors = self._process_anchors(*anchors)
        emd_result = self._transport_cost(*processed_anchors)
        return emd_result

    def evaluate(self, n: int, n_runs: int = 1, log=False, **kwargs) -> Union[EMDOutput, List[EMDOutput]]:
        """
        Transport plan estimation using `preprocess` method as a machinery for choosing n points.

        Parameters
        ----------
        n:
            Number of points passed to the LP solver.
        n_runs:
            Number of times the estimator will be called.
        log:
            Whether to return the cost or an EMDOutput object containing other information (duality gap, time, ...).
        kwargs:
            Passed to the `preprocess` method.

        Returns
        -------
        result:
            If log is False, returns the estimated transport cost. Otherwise, returns an EMDOutput.
            If n_runs > 1, returns a list of the result.
        """
        result = []
        for __ in range(n_runs):
            result.append(self._evaluate(n, **kwargs))

        if not log:
            # Returns only the cost
            result = [emd_run.transport_cost for emd_run in result]

        if n_runs == 1:
            # Returns only the first item
            return result[0]

        return result

    def plot_example(self, n, ax=None, prefactor=1, **kwargs):
        if ax is None:
            ax = plt.gca()
        ax: plt.Axes
        samples_x, clusters_x, weights_x, samples_y, clusters_y, weights_y = self._generate_anchors(n)
        ax.scatter(*samples_x[:, :2].T, c='b', marker='o', alpha=.5, **kwargs)
        ax.scatter(*clusters_x[:, :2].T, c='b', marker='^', s=weights_x*prefactor)
        ax.scatter(*samples_y[:, :2].T, c='r', marker='o', alpha=.5, **kwargs)
        ax.scatter(*clusters_y[:, :2].T, c='r', marker='^', s=weights_y*prefactor)
        return ax


class GenerateKMeans(EstimateOT, ABC):

    def _generate_anchors(self, n: int, ratio=None, *args, **kwargs):
        n_samples = int((n ** 2.) * (1 + np.log(n + 1))) if ratio is None else int(n ** ratio)
        n_samples = max(1, int(self.prefactor_sampling * n_samples))

        samples_x = self.alpha.sample(n_samples)
        samples_y = self.beta.sample(n_samples)

        clusters_x, weights_x = kmeans_init(samples_x, n, norm=self.norm)
        clusters_y, weights_y = kmeans_init(samples_y, n, norm=self.norm)

        return samples_x, clusters_x, weights_x, samples_y, clusters_y, weights_y


class GenerateMCKMeans(EstimateOT, ABC):

    def __init__(self, alpha: Distribution, beta: Distribution,
                 chain_length=0,
                 r_sampled=3.,
                 *args, **kwargs):
        super().__init__(alpha, beta, *args, **kwargs)
        self.chain_length = chain_length
        self.r_sampled = r_sampled

    def _generate_anchors(self, n: int, *args, **kwargs):
        chain_length = int(n ** 1.) if self.chain_length == 0 else self.chain_length

        # Complexity of AFK is O(nd) in the number of samples (preprocessing step)
        n_samples = int((n ** self.r_sampled) * (1 + np.log(n + 1)))

        samples_x = self.alpha.sample(n_samples)
        samples_y = self.beta.sample(n_samples)

        clusters_x = assumption_free_kmc2(samples_x, n, chain_length)
        clusters_y = assumption_free_kmc2(samples_y, n, chain_length)

        # Subsample points
        subsampled_x = samples_x[np.random.choice(n_samples, size=int(n**2 * (1 + np.log(n + 1))))]
        subsampled_y = samples_y[np.random.choice(n_samples, size=int(n**2 * (1 + np.log(n + 1))))]

        # Compute weights
        weights_x = anchor_weights(subsampled_x, anchors=clusters_x)
        weights_y = anchor_weights(subsampled_y, anchors=clusters_y)

        return subsampled_x, clusters_x, weights_x, subsampled_y, clusters_y, weights_y


def lloyd_refinment(cls: Union[Type[GenerateMCKMeans], Type[GenerateKMeans]]):
    class RefinedKMeans(cls, ABC):

        def _generate_anchors(self, n: int, *args, **kwargs):
            samples_x, clusters_x, weights_x, samples_y, clusters_y, weights_y = (
                super(RefinedKMeans, self)._generate_anchors(n=n, *args, **kwargs)
            )
            Estimator = SklearnKMeans if n < 1e4 else SklearnMiniKMeans

            model_x = Estimator(n_clusters=clusters_x.shape[0], init=clusters_x, max_iter=50, n_init=1)
            model_x.fit(samples_x)
            clusters_x = model_x.cluster_centers_.copy()

            model_y = Estimator(n_clusters=clusters_y.shape[0], init=clusters_y, max_iter=50, n_init=1)
            model_y.fit(samples_y)
            clusters_y = model_y.cluster_centers_.copy()

            weights_x = anchor_weights(samples_x, clusters_x)
            weights_y = anchor_weights(samples_y, clusters_y)

            return samples_x, clusters_x, weights_x, samples_y, clusters_y, weights_y
    return RefinedKMeans


class GenerateEmpirical(EstimateOT, ABC):

    def _generate_anchors(self, n: int, *args, **kwargs):
        uniform_weights = np.ones(n) / n
        samples_x = self.alpha.sample(n)
        samples_y = self.beta.sample(n)

        return (samples_x, samples_x, uniform_weights.copy(), samples_y, samples_y, uniform_weights.copy())


class ProcessCentroidCost(EstimateOT, ABC):

    def _process_anchors(self, samples_x, clusters_x, weights_x, samples_y, clusters_y, weights_y, *args, **kwargs):
        clusters_distance = self.metric(clusters_x, clusters_y)

        weights_x = weights_x / np.sum(weights_x)
        weights_y = weights_y / np.sum(weights_y)
        return samples_x, clusters_x, weights_x, samples_y, clusters_y, weights_y, clusters_distance


class TransportSimple(EstimateOT, ABC):

    def _transport_cost(self, samples_x, clusters_x, weights_x, samples_y, clusters_y, weights_y, clusters_distance,
                        *args, **kwargs) -> EMDOutput:
        return emd(weights_x, weights_y, clusters_distance)


class TransportRegularized(EstimateOT, ABC):

    def __init__(self, alpha: Distribution, beta: Distribution, *args, eps=1., **kwargs):
        super().__init__(alpha, beta, *args, **kwargs)
        self.eps = eps

    def _transport_cost(self, samples_x, clusters_x, weights_x, samples_y, clusters_y, weights_y, clusters_distance,
                        *args, **kwargs) -> EMDOutput:
        return sinkhorn(weights_x, weights_y, clusters_distance, self.eps)


class EmpiricalSampler(GenerateEmpirical, ProcessCentroidCost, TransportSimple):
    """
    Simplest estimator.
    1. Sample n points.
    2. Compute pairwise distance: nxn cost matrix.
    3. Compute OT.
    """
    pass


class EmpiricalSamplerRegularized(GenerateEmpirical, ProcessCentroidCost, TransportRegularized):
    pass


class KMeansInit(GenerateKMeans, ProcessCentroidCost, TransportSimple):
    """
    KMeans estimator.
    1. Sample n**r points. Use KMeans++ initialization to keep only n points.
    2. Compute pairwise distance between centroids: nxn cost matrix.
    3. Compute OT.
    """

    def _generate_anchors(self, n: int, *args, **kwargs):
        return super(KMeansInit, self)._generate_anchors(n, *args, **kwargs)


class KMeansInitRegularized(GenerateKMeans, ProcessCentroidCost, TransportRegularized):
    pass


class MCKMeansInit(GenerateMCKMeans, ProcessCentroidCost, TransportSimple):
    pass


class MCKMeansInitRegularized(GenerateMCKMeans, ProcessCentroidCost, TransportRegularized):
    pass


class MCKMeansInitLloydRefinement(lloyd_refinment(GenerateMCKMeans), ProcessCentroidCost, TransportSimple):
    pass


class KMeansInitLloydRefinement(lloyd_refinment(KMeansInit), ProcessCentroidCost, TransportSimple):
    pass
