import dill
import numpyro
import numpy as np
import pandas as pd
import geopandas as gpd

from utils import unstandardize
from shapely.geometry import Point
from matplotlib import pyplot as plt


def skill_with_preds(y_true, y_pred):
    """
    Function to compute skill given ground truth and predictions

    Arguments:
    - y_true: numpy.ndarray containing ground truth values
    - y_pred: numpy.ndarray containing predicted values
    """
    return 1 - np.sum(np.square(y_true - y_pred)) / np.sum(np.square(y_true))


def cosine_sim_with_preds(y_true, y_pred):
    """
    Function to compute cosine-similarity given ground truth and predictions

    Arguments:
    - y_true: numpy.ndarray containing ground truth values
    - y_pred: numpy.ndarray containing predicted values
    """
    inner_prod = np.sum(y_true * y_pred)
    norm_y_true = np.sqrt(np.sum(np.square(y_true)))
    norm_y_pred = np.sqrt(np.sum(np.square(y_pred)))
    return inner_prod / (norm_y_true * norm_y_pred)


def get_location_wise_metric(target_data_frame, preds_data_frame, metric):
    """
    Function to compute location wise metric given the target and predictions

    Arguments:
    - target_data_frame: target DataFrame with MultiIndex ('lat', 'lon', 'start_date')
    - preds_data_frame: predictions DataFrame with MultiIndex ('lat', 'lon', 'start_date')
    - metric: one of 'cosine-sim' or 'skill'
    """
    if metric == "skill":
        metric_func = skill_with_preds
    elif metric == "cosine-sim":
        metric_func = cosine_sim_with_preds
    else:
        raise ValueError(f"Invalid metric: {metric}")

    location_wise_metric_df = pd.DataFrame(columns=["lat", "lon", "metric"])
    for (node, target), (node_check, predict) in zip(
        target_data_frame.groupby(level=[0, 1]), preds_data_frame.groupby(level=[0, 1])
    ):
        assert node == node_check, "Node mismatch"
        metric_val = metric_func(
            target.to_numpy().reshape(-1, 1), predict.to_numpy().reshape(-1, 1)
        )
        location_wise_metric_df = location_wise_metric_df.append(
            {"lat": node[0], "lon": node[1], "metric": metric_val}, ignore_index=True
        )
    return location_wise_metric_df


def get_year_wise_metric(target_data_frame, preds_data_frame, metric):
    if metric == "skill":
        metric_func = skill_with_preds
    elif metric == "cosine-sim":
        metric_func = cosine_sim_with_preds
    else:
        raise ValueError(f"Invalid metric: {metric}")

    assert target_data_frame.index.equals(preds_data_frame.index), "Indices don't match"
    target_data_frame_unstacked = target_data_frame.unstack(["lat", "lon"])
    preds_data_frame_unstacked = preds_data_frame.unstack(["lat", "lon"])
    unique_years = target_data_frame_unstacked.index.year.unique().tolist()
    complete_index = target_data_frame_unstacked.index

    metric_dict = dict()
    for year in unique_years:
        indexer = (complete_index <= f"{year}-12-31") & (complete_index >= f"{year}-01-01")
        indexer = complete_index[indexer]
        target_df_year = target_data_frame_unstacked.loc[indexer]
        preds_df_year = preds_data_frame_unstacked.loc[indexer]
        metric_dict[year] = metric_func(
            target_df_year.to_numpy(copy=True), preds_df_year.to_numpy(copy=True)
        )

    return metric_dict


def get_coverage_interval_length_residuals(target_data_frame, prediction_samples, alpha=0.05):
    """
    Function to get coverage and interval length at level alpha and location and
    date wise residuals.
    The confidence interval [alpha / 2, 1 - alpha / 2] is computed using the
    given samples. Coverage of a value is whether the true value lies in this
    interval.

    Arguments:
    - target_data_frame: target DataFrame with MultiIndex ('lat', 'lon', 'start_date')
    - predictions_samples: numpy.ndarray of shape (n_samples, T, S)
    - alpha: significance level
    """
    lower, upper = numpyro.diagnostics.hpdi(prediction_samples, prob=(1 - 2 * alpha))
    target_matrix = target_data_frame.sort_index().unstack(["lat", "lon"]).to_numpy(copy=True)

    # Coverage computation
    check_coverage = (target_matrix >= lower) & (upper >= target_matrix)
    locations = target_data_frame.index.droplevel("start_date").unique().sort_values()
    dates = target_data_frame.index.droplevel(["lat", "lon"]).unique().sort_values()
    average_coverage = np.mean(check_coverage)
    location_wise_coverage = pd.DataFrame(
        np.mean(check_coverage, axis=0), index=locations, columns=["coverage"]
    )
    date_wise_coverage = pd.DataFrame(
        np.mean(check_coverage, axis=1), index=dates, columns=["coverage"]
    )

    # Interval length computation
    interval_length = upper - lower
    average_length = np.mean(interval_length)
    location_wise_length = pd.DataFrame(
        np.mean(interval_length, axis=0), index=locations, columns=["interval length"]
    )
    date_wise_length = pd.DataFrame(
        np.mean(interval_length, axis=1), index=dates, columns=["interval length"]
    )

    # Residual computation
    mean_prediction = np.mean(prediction_samples, axis=0)
    location_wise_residuals = pd.DataFrame(
        np.mean(mean_prediction - target_matrix, axis=0), index=locations, columns=["residual"]
    )
    date_wise_residuals = pd.DataFrame(
        np.mean(mean_prediction - target_matrix, axis=1), index=dates, columns=["residual"]
    )

    return {
        "average_coverage": average_coverage,
        "location_wise_coverage": location_wise_coverage,
        "date_wise_coverage": date_wise_coverage,
        "average_length": average_length,
        "location_wise_length": location_wise_length,
        "date_wise_length": date_wise_length,
        "location_wise_residuals": location_wise_residuals,
        "date_wise_residuals": date_wise_residuals,
    }


def visualize_data_frame_map(data_frame, save_name, shape_file=None, resolution=2):
    """
    Function to plot values on a map, where the locations and values are given by the DataFrame

    Arguments:
    - data_frame: DataFrame with MultiIndex ('lat', 'lon')
    - save_name: location to save the plot to
    - shape_file: overlay a shape file with borders
    - resolution: resolution of the locations
    """
    plt.rcParams.update({"font.size": 18})
    geometry = [
        Point(lon, lat).buffer(resolution / 2, cap_style=3)
        for lon, lat in zip(data_frame.lon, data_frame.lat)
    ]

    to_plot = next(iter(set(data_frame.columns.tolist()) - set(["lat", "lon"])))
    complete_gdf = gpd.GeoDataFrame(data_frame.copy(), geometry=geometry)
    fig, ax = plt.subplots()
    complete_gdf.plot(column=to_plot, edgecolor="none", linewidth=0.1, legend=True, ax=ax)
    if shape_file is not None:
        outline_gdf = gpd.read_file(shape_file)
        outline_gdf.plot(color="none", edgecolor="black", ax=ax)

    if save_name is None:
        plt.show()
    else:
        plt.savefig(save_name, format="pdf")
        plt.close()


def visualize_data_frame_date(data_frame, save_name):
    """
    Function to plot values on a map, where the dates and values are given by the DataFrame

    Arguments:
    - data_frame: DataFrame with Index ('start_date')
    - save_name: location to save the plot to
    """
    fig, ax = plt.subplots()
    data_frame.plot(legend=False, ax=ax)
    plt.xlabel("date")
    plt.ylabel(data_frame.columns[0])
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.savefig(save_name, format="pdf")
    plt.close()


def generate_all_evaluation_plots(
    target_data_frame,
    preds_data_frame,
    raw_predictions,
    std_data_frame,
    plot_name_prefix,
    shape_file=None,
):
    """
    Function to plot all evaluation information (metrics, coverage, interval, residuals).

    Arguments:
    - target_data_frame: target DataFrame with Index ('lat', 'lon', 'start_date')
    - preds_data_frame: actual predictions DataFrame with Index ('lat', 'lon', 'start_date')
    - raw_predictions: numpy.ndarray of shape (n_samples, T, S) containing prediction samples
    - std_data_frame: DataFrame with Index ('lat', 'lon', 'start_date') containing std.devs
    - plot_name_prefix: prefix for saving plot names
    - shape_file: shape file to overlay on map
    """
    location_wise_cossim = get_location_wise_metric(
        target_data_frame=target_data_frame, preds_data_frame=preds_data_frame, metric="cosine-sim"
    )
    location_wise_skill = get_location_wise_metric(
        target_data_frame=target_data_frame, preds_data_frame=preds_data_frame, metric="skill"
    )
    year_wise_cossim = get_year_wise_metric(
        target_data_frame=target_data_frame, preds_data_frame=preds_data_frame, metric="cosine-sim"
    )
    year_wise_skill = get_year_wise_metric(
        target_data_frame=target_data_frame, preds_data_frame=preds_data_frame, metric="skill"
    )
    print("Skill: ", skill_with_preds(target_data_frame.values, preds_data_frame.values))
    print("Cosine-Sim: ", cosine_sim_with_preds(target_data_frame.values, preds_data_frame.values))
    visualize_data_frame_map(
        data_frame=location_wise_cossim,
        save_name=f"{plot_name_prefix}_cossim.pdf",
        shape_file=shape_file,
    )
    visualize_data_frame_map(
        data_frame=location_wise_skill,
        save_name=f"{plot_name_prefix}_skill.pdf",
        shape_file=shape_file,
    )
    metric_dict = {
        "location_wise_cossim": location_wise_cossim,
        "location_wise_skill": location_wise_skill,
        "year_wise_cossim": year_wise_cossim,
        "year_wise_skill": year_wise_skill,
    }

    # We manually scale one of the predictions
    one_prediction = raw_predictions[0].copy()
    one_prediction = (
        pd.DataFrame(
            one_prediction,
            index=preds_data_frame.unstack(["lat", "lon"]).index.shift(-28, freq="d"),
            columns=preds_data_frame.unstack(["lat", "lon"]).columns,
        )
        .stack(["lat", "lon"])
        .reorder_levels(["lat", "lon", "start_date"])
        .sort_index()
    )
    one_prediction = unstandardize(data_frame=one_prediction, std_data_frame=std_data_frame)
    one_prediction = one_prediction.unstack(["lat", "lon"])

    # Now we extract the precise scaling values and use broadcasting to speed up scaling
    factor_matrix = one_prediction.values / raw_predictions[0]
    raw_predictions_us = raw_predictions * factor_matrix

    prediction_diag = get_coverage_interval_length_residuals(
        target_data_frame=target_data_frame, prediction_samples=raw_predictions_us
    )
    for key, value in prediction_diag.items():
        if key.find("location") != -1:
            visualize_data_frame_map(
                data_frame=value.reset_index(),
                save_name=f"{plot_name_prefix}_{key}.pdf",
                shape_file=shape_file,
            )
        elif key.find("date") != -1:
            visualize_data_frame_date(data_frame=value, save_name=f"{plot_name_prefix}_{key}.pdf")
        else:
            print(f"{key}: {value}")

    prediction_diag.update(metric_dict)
    dill.dump(prediction_diag, open(f"{plot_name_prefix}_artifacts.pkl", "wb"))
