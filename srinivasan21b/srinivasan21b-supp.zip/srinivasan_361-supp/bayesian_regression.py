import dill
import time
import numpyro
import numpy as np
import pandas as pd
import jax.numpy as jnp

from jax import random
from argparse import ArgumentParser
from numpyro import distributions as dist
from numpyro.infer import MCMC, NUTS, Predictive

from utils import (
    construct_graph_laplacian_target_matrix,
    subsample_all_dates,
    unstandardize,
    compute_pca,
)
from model_diagnostics import generate_all_evaluation_plots


def model(X, L, rho_hp, tau_j_hp, tau_eps_hp, y=None):
    """
    Numpyro-type model for Bayesian Regression

    Arguments:
    - X: Covariate matrix of size (T x d)
    - L: Laplacian of graph of locations
    - rho_hp: Hyperparameter for the Beta distribution generating rho
    - tau_j_hp: Hyperparameter for the InverseGamma distribution generating tau_js
    - tau_eps_hp: Hyperparameter for the InverseGamma distribution generating tau_eps
    - y: Target matrix of size (T x S) (default: None)
    """
    T, d = X.shape
    S = L.shape[0]
    rho = numpyro.sample("rho", dist.Beta(rho_hp[0], rho_hp[1]))
    Sigma_inv = rho * L + (1 - rho) * jnp.eye(S)  # Inverse of Sigma(rho)
    Sigma_chol = dist.util.cholesky_of_inverse(Sigma_inv)  # Cholesky factor of Sigma(rho)

    # Sampling: tau_eps, tau_js
    tau_eps_sq = numpyro.sample("tau_eps_sq", dist.InverseGamma(tau_eps_hp[0], tau_eps_hp[1]))
    tau_eps = numpyro.deterministic("tau_eps", jnp.sqrt(tau_eps_sq))
    tau_js_sq = numpyro.sample(
        "tau_js_sq", dist.InverseGamma(tau_j_hp[0], tau_j_hp[1]).expand((d,))
    )

    # The covariance is obtained after marginalizing out beta_0 in the original model
    lambd = numpyro.sample("lambd", dist.Gamma(10.0, 10.0))
    eye_mult = 1 / (S * T * lambd)
    beta_cov = eye_mult * jnp.eye(S) + Sigma_chol @ Sigma_chol.T * tau_js_sq.reshape(d, 1, 1)
    betas = numpyro.sample("betas", dist.MultivariateNormal(covariance_matrix=beta_cov))

    mean = X @ betas  # Obtain means
    with numpyro.plate("plate", T):  # Sample predictions
        numpyro.sample(
            "y", dist.MultivariateNormal(loc=mean, scale_tril=Sigma_chol * tau_eps), obs=y
        )


def train_spatial_regression(
    covariate_data_frame,
    target_data_frame,
    hyperparam_dict,
    num_warmup=1000,
    num_samples=2000,
    silent=False,
):
    """
    Function to return MCMC model after training.

    Arguments:
    - covariate_data_frame: a DataFrame with d columns, where d is the number of features
    - target_data_frame: a DataFrame with S columns, where S is the number of locations to
                         predict over
    - hyperparam_dict: hyperparameter dictionary for the Bayesian model
    - num_warmup: number of warmup samples
    - num_samples: number of samples to store after the warmup phase
    """
    X = covariate_data_frame.to_numpy(copy=True)
    L, y, vertices = construct_graph_laplacian_target_matrix(target_data_frame)

    nuts_kernel = NUTS(model, max_tree_depth=10, dense_mass=False)
    rng_key = random.PRNGKey(0)
    rng_key, rng_key_ = random.split(rng_key)

    mcmc = MCMC(
        nuts_kernel, num_warmup=num_warmup, num_samples=num_samples, progress_bar=not silent
    )
    mcmc.run(rng_key_, X=X, y=y, L=L, **hyperparam_dict)
    return mcmc, L


def obtain_predictions(covariate_data_frames, mcmc_instance, laplacian, hyperparam_dict):
    """
    Function to obtain predictions from the model after training.

    Arguments:
    - covariate_data_frames: a list of DataFrames with d columns each,
                             where d is the number of features
    - mcmc_instance: a MCMC object after training
    - laplacian: Laplacian of graph of locations
    - hyperparam_dict: hyperparameter dictionary for the Bayesian model
    """
    rng_key = random.PRNGKey(1)
    predictor = Predictive(model, mcmc_instance.get_samples())

    predictions = []
    for cov_df in covariate_data_frames:
        rng_key, rng_key_ = random.split(rng_key)
        X = cov_df.to_numpy(copy=True)
        predictions.append(np.array(predictor(rng_key_, X=X, L=laplacian, **hyperparam_dict)["y"]))
    return predictions


def run_bayesian(
    train_covariate_data_frame,
    train_target_data_frame,
    test_covariate_data_frame,
    hyperparam_dict,
    num_warmup,
    num_samples,
    silent,
):
    """
    Function to run the Bayesian model and get predictions
    """
    mcmc_instance, laplacian = train_spatial_regression(
        covariate_data_frame=train_covariate_data_frame,
        target_data_frame=train_target_data_frame,
        hyperparam_dict=hyperparam_dict,
        num_warmup=num_warmup,
        num_samples=num_samples,
        silent=silent,
    )
    predictions = obtain_predictions(
        covariate_data_frames=[train_covariate_data_frame, test_covariate_data_frame],
        mcmc_instance=mcmc_instance,
        laplacian=laplacian,
        hyperparam_dict=hyperparam_dict,
    )
    return predictions, mcmc_instance


if __name__ == "__main__":
    p = ArgumentParser()
    p.add_argument(
        "--train_covariates",
        type=str,
        required=True,
        help="Specify the location of the train covariates",
    )
    p.add_argument(
        "--train_targets",
        type=str,
        required=True,
        help="Specify the location of the train targets (standardized)",
    )
    p.add_argument(
        "--test_covariates",
        type=str,
        required=True,
        help="Specify the location of the test covariates",
    )
    p.add_argument(
        "--test_targets",
        type=str,
        required=True,
        help="Specify the location of the test targets (unstandardized)",
    )
    p.add_argument(
        "--std_data_frame",
        type=str,
        required=True,
        help="Specify the location of the day-wise standard deviation data frame",
    )
    p.add_argument(
        "--save_predictions",
        type=str,
        default=None,
        help="Specify the location to save the predictions",
    )
    p.add_argument(
        "--save_mcmc", type=str, default=None, help="Specify the location to save the MCMC model"
    )
    p.add_argument("--rho_a", type=float, default=8.0, help="a for Beta prior on rho")
    p.add_argument("--rho_b", type=float, default=2.0, help="b for Beta prior on rho")
    p.add_argument(
        "--tau_j_a", type=float, default=100.0, help="a for Inverse Gamma prior on tau_j"
    )
    p.add_argument("--tau_j_b", type=float, default=0.01, help="b for Inverse Gamma prior on tau_j")
    p.add_argument(
        "--tau_eps_a", type=float, default=32.0, help="a for Inverse Gamma prior on tau_eps"
    )
    p.add_argument(
        "--tau_eps_b", type=float, default=0.906 * 31, help="b for Inverse Gamma prior on tau_eps"
    )
    p.add_argument("--num_warmup", type=int, default=1000, help="Number of warmup samples")
    p.add_argument("--num_samples", type=int, default=2000, help="Number of samples saved")
    p.add_argument(
        "--subsample_factor",
        type=int,
        default=4,
        help="Ratio for subsampling locations (r * 0.5 x r * 0.5)",
    )
    p.add_argument("--silent", action="store_true", help="Toggle to not display progress bar")
    p.add_argument("--num_features", type=int, default=20, help="Number of PCA features to use")
    p.add_argument(
        "--plot_name_prefix",
        type=str,
        default=f"outputs_regression/{time.strftime('%d:%m:%yT%T')}",
        help="Prefix for plot names",
    )
    p.add_argument(
        "--shape_file", type=str, default="shape_files/western_us.shp", help="Shape file location"
    )
    p.add_argument("--only_eval", action="store_true", help="Toggle to run evaluation alone")
    args = p.parse_args()

    train_covariate_data_frame = pd.read_hdf(args.train_covariates)
    train_target_data_frame = pd.read_hdf(args.train_targets)
    test_covariate_data_frame = pd.read_hdf(args.test_covariates)

    hyperparam_dict = dict()
    hyperparam_dict["rho_hp"] = (args.rho_a, args.rho_b)
    hyperparam_dict["tau_j_hp"] = (args.tau_j_a, args.tau_j_b)
    hyperparam_dict["tau_eps_hp"] = (args.tau_eps_a, args.tau_eps_b)

    train_target_data_frame_ss = subsample_all_dates(
        data_frame=train_target_data_frame,
        subsample_factor=args.subsample_factor,
        silent=args.silent,
    )
    locations = train_target_data_frame_ss.unstack(["lat", "lon"]).columns

    train_covariate_data_frame = train_covariate_data_frame.unstack(["lat", "lon"])
    train_dates = train_covariate_data_frame.index
    pca_obj = compute_pca(
        matrix=train_covariate_data_frame.to_numpy(copy=True), n_components=args.num_features
    )

    train_covariate_data_frame = pd.DataFrame(
        pca_obj.transform(train_covariate_data_frame.to_numpy(copy=True)), index=train_dates
    )

    test_covariate_data_frame = test_covariate_data_frame.unstack(["lat", "lon"])
    test_dates = test_covariate_data_frame.index
    test_covariate_data_frame = pd.DataFrame(
        pca_obj.transform(test_covariate_data_frame.to_numpy(copy=True)), index=test_dates
    )

    if not args.only_eval:
        predictions, mcmc_instance = run_bayesian(
            train_covariate_data_frame=train_covariate_data_frame,
            train_target_data_frame=train_target_data_frame_ss,
            test_covariate_data_frame=test_covariate_data_frame,
            hyperparam_dict=hyperparam_dict,
            num_warmup=args.num_warmup,
            num_samples=args.num_samples,
            silent=args.silent,
        )

        if args.save_predictions:
            dill.dump(predictions, open(f"{args.plot_name_prefix}_{args.save_predictions}", "wb"))

        if args.save_mcmc:
            dill.dump(mcmc_instance, open(f"{args.plot_name_prefix}_{args.save_mcmc}", "wb"))

    else:
        if not args.save_predictions or not args.save_mcmc:
            raise ValueError("Cannot run eval without predictions")

        predictions = dill.load(open(f"{args.plot_name_prefix}_{args.save_predictions}", "rb"))
        mcmc_instance = dill.load(open(f"{args.plot_name_prefix}_{args.save_mcmc}", "rb"))

    std = pd.read_hdf(args.std_data_frame, key="std")

    # Rescaling train targets to unstandardized anomalies (0.5 x 0.5 level)
    train_target_data_frame = unstandardize(train_target_data_frame, std)

    # train_target_data_frame_us_ss is the unstandardized anomaly,
    # subsampled to required resolution.
    train_target_data_frame_us_ss = subsample_all_dates(
        data_frame=train_target_data_frame,
        subsample_factor=args.subsample_factor,
        silent=args.silent,
    )

    # test_target_data_frame_ss is the unstandardized anomaly,
    # subsampled to required resolution.
    test_target_data_frame_ss = subsample_all_dates(
        data_frame=pd.read_hdf(args.test_targets),
        subsample_factor=args.subsample_factor,
        silent=args.silent,
    )

    # Subsample standard deviation to match resolution.
    # Here, for a group of locations, we consider the aggregate stddev
    # at time t to be the RMS of the stddevs of the locations in the group.
    std = std ** 2.0
    std_subsampled = subsample_all_dates(
        data_frame=std, subsample_factor=args.subsample_factor, silent=args.silent
    )
    std_subsampled = std_subsampled ** 0.5

    # Decision theoretic minimizer of the MSE Loss
    predictions_train_mse = (
        pd.DataFrame(np.mean(predictions[0], axis=0), index=train_dates, columns=locations)
        .stack(["lat", "lon"])
        .reorder_levels(["lat", "lon", "start_date"])
        .sort_index()
    )
    predictions_train_mse = unstandardize(
        data_frame=predictions_train_mse, std_data_frame=std_subsampled
    ).unstack(["lat", "lon"])
    # Move to match target date index
    predictions_train_mse.index = predictions_train_mse.index.shift(28, freq="d")
    predictions_train_mse = (
        predictions_train_mse.stack(["lat", "lon"])
        .reorder_levels(["lat", "lon", "start_date"])
        .sort_index()
    )
    generate_all_evaluation_plots(
        target_data_frame=train_target_data_frame_us_ss,
        preds_data_frame=predictions_train_mse,
        raw_predictions=predictions[0],
        std_data_frame=std_subsampled,
        plot_name_prefix=f"{args.plot_name_prefix}_train_mse",
        shape_file="shape_files/western_us.shp",
    )

    predictions_test_mse = (
        pd.DataFrame(np.mean(predictions[1], axis=0), index=test_dates, columns=locations)
        .stack(["lat", "lon"])
        .reorder_levels(["lat", "lon", "start_date"])
        .sort_index()
    )
    predictions_test_mse = unstandardize(
        data_frame=predictions_test_mse, std_data_frame=std_subsampled
    ).unstack(["lat", "lon"])
    # Move to match target date index
    predictions_test_mse.index = predictions_test_mse.index.shift(28, freq="d")
    predictions_test_mse = (
        predictions_test_mse.stack(["lat", "lon"])
        .reorder_levels(["lat", "lon", "start_date"])
        .sort_index()
    )
    generate_all_evaluation_plots(
        target_data_frame=test_target_data_frame_ss,
        preds_data_frame=predictions_test_mse,
        raw_predictions=predictions[1],
        std_data_frame=std_subsampled,
        plot_name_prefix=f"{args.plot_name_prefix}_test_mse",
        shape_file="shape_files/western_us.shp",
    )
