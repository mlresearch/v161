import numpy as np
import pandas as pd

from itertools import product
from argparse import ArgumentParser

from xgboost import XGBRegressor
from sklearn.linear_model import MultiTaskLasso
from sklearn.neural_network import MLPRegressor
from sklearn.multioutput import MultiOutputRegressor

from utils import compute_pca, subsample_all_dates, unstandardize
from model_diagnostics import (
    skill_with_preds,
    cosine_sim_with_preds,
    get_location_wise_metric,
    get_year_wise_metric,
    visualize_data_frame_map,
)


def run_neuralnetwork(hidden_layer_sizes, activation, train_x, train_y, test_x):
    mlp = MLPRegressor(hidden_layer_sizes=hidden_layer_sizes, activation=activation, solver="lbfgs")
    mlp.fit(train_x, train_y)
    return mlp.predict(test_x), mlp


def run_xgboost(learning_rate, max_depth, n_estimators, train_x, train_y, test_x):
    xgb = MultiOutputRegressor(
        XGBRegressor(
            n_jobs=10,
            objective="reg:squarederror",
            verbosity=0,
            learning_rate=learning_rate,
            max_depth=max_depth,
            n_estimators=n_estimators,
        )
    )
    xgb.fit(train_x, train_y)
    return xgb.predict(test_x), xgb


def run_multitasklasso(alpha, train_x, train_y, test_x):
    mtl = MultiTaskLasso(max_iter=5000, alpha=alpha)
    mtl.fit(train_x, train_y)
    return mtl.predict(test_x), mtl


def generate_evaluation_plots(
    target_data_frame, preds_data_frame, plot_name_prefix, shape_file=None
):
    location_wise_cossim = get_location_wise_metric(
        target_data_frame=target_data_frame, preds_data_frame=preds_data_frame, metric="cosine-sim"
    )
    location_wise_skill = get_location_wise_metric(
        target_data_frame=target_data_frame, preds_data_frame=preds_data_frame, metric="skill"
    )
    year_wise_cossim = get_year_wise_metric(
        target_data_frame=target_data_frame, preds_data_frame=preds_data_frame, metric="cosine-sim"
    )
    year_wise_skill = get_year_wise_metric(
        target_data_frame=target_data_frame, preds_data_frame=preds_data_frame, metric="skill"
    )
    print("Skill: ", skill_with_preds(target_data_frame.values, preds_data_frame.values))
    print("Cosine-Sim: ", cosine_sim_with_preds(target_data_frame.values, preds_data_frame.values))
    visualize_data_frame_map(
        data_frame=location_wise_cossim,
        save_name=f"{plot_name_prefix}_cossim.pdf",
        shape_file=shape_file,
    )
    visualize_data_frame_map(
        data_frame=location_wise_skill,
        save_name=f"{plot_name_prefix}_skill.pdf",
        shape_file=shape_file,
    )
    metric_dict = {
        "location_wise_cossim": location_wise_cossim,
        "location_wise_skill": location_wise_skill,
        "year_wise_cossim": year_wise_cossim,
        "year_wise_skill": year_wise_skill,
    }
    return metric_dict


if __name__ == "__main__":
    p = ArgumentParser()
    p.add_argument(
        "--train_covariates",
        type=str,
        required=True,
        help="Specify the location of the train covariates",
    )
    p.add_argument(
        "--train_targets",
        type=str,
        required=True,
        help="Specify the location of the train targets (standardized)",
    )
    p.add_argument(
        "--test_covariates",
        type=str,
        required=True,
        help="Specify the location of the test covariates",
    )
    p.add_argument(
        "--test_targets",
        type=str,
        required=True,
        help="Specify the location of the test targets (unstandardized)",
    )
    p.add_argument(
        "--std_data_frame",
        type=str,
        required=True,
        help="Specify the location of the day-wise standard deviation data frame",
    )
    p.add_argument(
        "--model",
        type=str,
        required=True,
        choices=["nn", "xgb", "mtl"],
        help="Model to run cross validation over",
    )
    p.add_argument(
        "--subsample_factor",
        type=int,
        default=4,
        help="Ratio for subsampling locations (r * 0.5 x r * 0.5)",
    )
    p.add_argument("--num_features", type=int, default=20, help="Number of PCA features to use")
    p.add_argument("--silent", action="store_true", help="Toggle to not display progress bar")
    args = p.parse_args()

    train_covariate_data_frame = pd.read_hdf(args.train_covariates)
    train_target_data_frame = pd.read_hdf(args.train_targets)
    test_covariate_data_frame = pd.read_hdf(args.test_covariates)

    train_target_data_frame_ss = subsample_all_dates(
        data_frame=train_target_data_frame,
        subsample_factor=args.subsample_factor,
        silent=args.silent,
    )
    locations = train_target_data_frame_ss.unstack(["lat", "lon"]).columns

    train_covariate_data_frame = train_covariate_data_frame.unstack(["lat", "lon"])
    train_dates = train_covariate_data_frame.index
    pca_obj = compute_pca(
        matrix=train_covariate_data_frame.to_numpy(copy=True), n_components=args.num_features
    )
    train_covariate_data_frame = pd.DataFrame(
        pca_obj.transform(train_covariate_data_frame.to_numpy(copy=True)), index=train_dates
    )

    test_covariate_data_frame = test_covariate_data_frame.unstack(["lat", "lon"])
    test_dates = test_covariate_data_frame.index
    test_covariate_data_frame = pd.DataFrame(
        pca_obj.transform(test_covariate_data_frame.to_numpy(copy=True)), index=test_dates
    )

    validation_set_train_covariate_data_frame = train_covariate_data_frame[
        train_covariate_data_frame < "1996-01-01"
    ]
    validation_set_train_target_data_frame = train_target_data_frame_ss.unstack(["lat", "lon"])[
        validation_set_train_covariate_data_frame.index.shift(28, freq="d")
    ]

    validation_set_valid_covariate_data_frame = train_covariate_data_frame[
        train_covariate_data_frame >= "1996-01-01"
    ]
    validation_set_valid_target_data_frame = train_target_data_frame_ss.unstack(["lat", "lon"])[
        validation_set_valid_covariate_data_frame.index.shift(28, freq="d")
    ]

    if args.model == "nn":
        hidden_layer_sizes_choices = [(76,), (51, 102), (38, 76, 114)]
        activation_choices = ["relu", "tanh", "identity"]

        matrix = dict()
        for hidden_layer_sizes, activation in product(
            hidden_layer_sizes_choices, activation_choices
        ):
            valid_pred, _ = run_neuralnetwork(
                hidden_layer_sizes,
                activation,
                validation_set_train_covariate_data_frame.to_numpy(copy=True),
                validation_set_train_target_data_frame.to_numpy(copy=True),
                validation_set_valid_covariate_data_frame.to_numpy(copy=True),
            )
            error = np.sum(
                np.square(valid_pred - validation_set_valid_target_data_frame.to_numpy(copy=True))
            )
            matrix[(hidden_layer_sizes, activation)] = error

        best_config = min(matrix, key=matrix.get)

        test_prediction, NN = run_neuralnetwork(
            best_config[0],
            best_config[1],
            best_config[2],
            train_covariate_data_frame.to_numpy(copy=True),
            train_target_data_frame.unstack(["lat", "lon"]).to_numpy(copy=True),
            test_covariate_data_frame.to_numpy(copy=True),
        )

        train_prediction = NN.predict(train_covariate_data_frame.to_numpy(copy=True))

    elif args.model == "xgb":
        learning_rate_choices = [0.001, 0.01, 0.1]
        max_depth_choices = [4, 8]
        n_estimators_choices = [50, 100, 200]

        matrix = dict()
        for learning_rate, max_depth, n_estimators in product(
            learning_rate_choices, max_depth_choices, n_estimators_choices
        ):
            valid_pred, _ = run_xgboost(
                learning_rate,
                max_depth,
                n_estimators,
                validation_set_train_covariate_data_frame.to_numpy(copy=True),
                validation_set_train_target_data_frame.to_numpy(copy=True),
                validation_set_valid_covariate_data_frame.to_numpy(copy=True),
            )
            error = np.sum(
                np.square(valid_pred - validation_set_valid_target_data_frame.to_numpy(copy=True))
            )
            matrix[(hidden_layer_sizes, activation)] = error

    elif args.model == "mtl":
        alpha_choices = [0.001, 0.002, 0.005, 0.01, 0.02, 0.05, 0.1, 0.2, 0.5]

        matrix = dict()
        for alpha in alpha_choices:
            valid_pred, _ = run_multitasklasso(
                alpha,
                validation_set_train_covariate_data_frame.to_numpy(copy=True),
                validation_set_train_target_data_frame.to_numpy(copy=True),
                validation_set_valid_covariate_data_frame.to_numpy(copy=True),
            )
            error = np.sum(
                np.square(valid_pred - validation_set_valid_target_data_frame.to_numpy(copy=True))
            )
            matrix[(hidden_layer_sizes, activation)] = error

    std = pd.read_hdf(args.std_data_frame, key="std")

    # Rescaling train targets to unstandardized anomalies (0.5 x 0.5 level)
    train_target_data_frame = unstandardize(train_target_data_frame, std)

    # train_target_data_frame_us_ss is the unstandardized anomaly,
    # subsampled to required resolution.
    train_target_data_frame_us_ss = subsample_all_dates(
        data_frame=train_target_data_frame,
        subsample_factor=args.subsample_factor,
        silent=args.silent,
    )

    # test_target_data_frame_ss is the unstandardized anomaly,
    # subsampled to required resolution.
    test_target_data_frame_ss = subsample_all_dates(
        data_frame=pd.read_hdf(args.test_targets),
        subsample_factor=args.subsample_factor,
        silent=args.silent,
    )

    # Subsample standard deviation to match resolution.
    # Here, for a group of locations, we consider the aggregate stddev
    # at time t to be the RMS of the stddevs of the locations in the group.
    std = std ** 2.0
    std_subsampled = subsample_all_dates(
        data_frame=std, subsample_factor=args.subsample_factor, silent=args.silent
    )
    std_subsampled = std_subsampled ** 0.5

    train_prediction = (
        pd.DataFrame(train_prediction, index=train_dates, columns=locations)
        .stack(["lat", "lon"])
        .reorder_levels(["lat", "lon", "start_date"])
        .sort_index()
    )
    train_prediction = unstandardize(
        data_frame=train_prediction, std_data_frame=std_subsampled
    ).unstack(["lat", "lon"])
    # Move to match target date index
    train_prediction.index = train_prediction.index.shift(28, freq="d")
    train_prediction = (
        train_prediction.stack(["lat", "lon"])
        .reorder_levels(["lat", "lon", "start_date"])
        .sort_index()
    )

    generate_evaluation_plots(
        target_data_frame=train_target_data_frame_us_ss,
        preds_data_frame=train_prediction,
        plot_name_prefix=f"{args.model}_train",
        shape_file="shape_files/western_us.shp",
    )

    test_prediction = (
        pd.DataFrame(test_prediction, index=test_dates, columns=locations)
        .stack(["lat", "lon"])
        .reorder_levels(["lat", "lon", "start_date"])
        .sort_index()
    )
    test_prediction = unstandardize(
        data_frame=test_prediction, std_data_frame=std_subsampled
    ).unstack(["lat", "lon"])
    # Move to match target date index
    test_prediction.index = test_prediction.index.shift(28, freq="d")
    test_prediction = (
        test_prediction.stack(["lat", "lon"])
        .reorder_levels(["lat", "lon", "start_date"])
        .sort_index()
    )

    generate_evaluation_plots(
        target_data_frame=test_target_data_frame_ss,
        preds_data_frame=test_prediction,
        plot_name_prefix=f"{args.model}_test",
        shape_file="shape_files/western_us.shp",
    )
