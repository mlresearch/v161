import calendar
import numpy as np
import pandas as pd
import networkx as nx
import scipy.spatial.distance as ssd

from tqdm import tqdm
from sklearn.decomposition import PCA


def construct_graph_laplacian_target_matrix(target_data_frame):
    """
    Function to create graph laplacian and the target matrix from a target DataFrame

    Arguments:
    - target_data_frame: data frame with MultiIndex ('lat', 'lon', 'start_date')
    """
    unstacked = target_data_frame.sort_index().unstack(["lat", "lon"])
    vertices = unstacked.columns.tolist()
    target_matrix = unstacked.to_numpy(copy=True)
    resolution = min(ssd.pdist(vertices))
    adjacency_matrix = pd.DataFrame(
        ssd.squareform(ssd.pdist(vertices)) == resolution, columns=vertices, index=vertices
    )  # This will create the nodes and edges
    graph = nx.from_pandas_adjacency(adjacency_matrix)
    graph = nx.OrderedGraph(graph)
    laplacian = nx.laplacian_matrix(graph).toarray()
    return (laplacian, target_matrix, vertices)


def subsample_one_date(series, all_locations, all_longs, all_lats, date, subsample_factor):
    """
    Function to subsample one date.

    Arguments:
    - series: Series with MultiIndex ('lat', 'lon')
    - all_locations: MultiIndex of 'lat', 'lon'
    - all_longs: List of longitudes
    - all_lats: List of latitudes
    - date: date to generate subsampled dataframe
    - subsample_factor: length of side of subsampling patch
    """
    cart_prod = pd.DataFrame(columns=all_longs, index=all_lats)
    for loc in all_locations:
        cart_prod[loc[1]][loc[0]] = series[(loc[0], loc[1])]
    cart_prod = cart_prod.to_numpy(copy=True).astype(float)

    patch_coords = []
    for i in range(0, len(all_lats), subsample_factor):
        lat_mean = np.mean(all_lats[i : i + subsample_factor])
        for j in range(0, len(all_longs), subsample_factor):
            patch = cart_prod[i : i + subsample_factor, j : j + subsample_factor]
            long_mean = np.mean(all_longs[j : j + subsample_factor])
            if np.isnan(patch).sum() < 0.7 * patch.size:
                patch_coords.append(
                    {"lat": lat_mean, "lon": long_mean, "start_date": date, 0: np.nanmean(patch)}
                )
    sub_df = pd.DataFrame(patch_coords)
    return sub_df


def subsample_all_dates(data_frame, subsample_factor, silent=False):
    """
    Function to generate the complete data frame after subsampling.

    Arguments:
    - data_frame: Original DataFrame with MultiIndex ('lat', 'lon', 'start_date')
    - subsample_factor: length of side of subsampling patch
    - silent: option to silence tqdm progress bar (default: False)
    """
    df_index = data_frame.index
    all_locations = df_index.droplevel("start_date").unique()
    all_lats = all_locations.droplevel(["lon"]).unique().sort_values(ascending=False)
    all_longs = all_locations.droplevel(["lat"]).unique().sort_values()

    subsampled_dfs = []
    for date, data_frame_time in tqdm(
        data_frame.groupby(level=[2]), desc="subsample", unit="date", ascii=True, disable=silent
    ):
        series = data_frame_time.droplevel("start_date")
        subsampled_dfs.append(
            subsample_one_date(series, all_locations, all_longs, all_lats, date, subsample_factor)
        )
    return pd.concat(subsampled_dfs).set_index(["lat", "lon", "start_date"]).sort_index()


def compute_pca(matrix, n_components):
    """
    Function to perform PCA on a matrix.

    Arguments:
    - matrix: np.ndarray of size m x n
    - n_components: number of principal components (n_components < n)
    """
    pca_obj = PCA(n_components=n_components)
    pca_obj.fit(matrix)
    return pca_obj


def unstandardize(data_frame, std_data_frame):
    """
    Function to unstandardize the give data using the standard deviations
    i.e., multiplying the stddevs.

    Arguments:
    - data_frame: Original standardized DataFrame with MultiIndex ('lat', 'lon', 'start_date')
    - std_data_frame: Standard deviation DataFrame with MultiIndex ('lat', 'lon', 'start_date')
    """
    std_data_frame_unstack = std_data_frame.unstack(["lat", "lon"])
    data_frame_us = data_frame.unstack(["lat", "lon"])
    for year in data_frame_us.index.year.unique():
        if calendar.isleap(year):
            std_year = std_data_frame_unstack.copy()
        else:
            std_year = std_data_frame_unstack.copy()[
                ~(
                    (std_data_frame_unstack.index.day == 29)
                    & (std_data_frame_unstack.index.month == 2)
                )
            ]
        std_year.index = std_year.index.map(lambda idx: idx.replace(year=year))
        data_frame_us[data_frame_us.index.year == year] *= std_year

    data_frame_us = (
        data_frame_us.stack(["lat", "lon"])
        .reorder_levels(["lat", "lon", "start_date"])
        .sort_index()
    )
    return data_frame_us
