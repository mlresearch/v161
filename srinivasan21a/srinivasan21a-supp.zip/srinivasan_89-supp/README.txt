- Install ananke (https://ananke.readthedocs.io/en/latest/):
	- pip3 install ananke-causal

- Execute intervention.py to run the entire simulation, and get the output plot.

- Other files:
	- generative_model.py generates data, stored in folder sim2/
	- estimation.py uses maximum likelihood to estimate model parameters using data in sim2/
