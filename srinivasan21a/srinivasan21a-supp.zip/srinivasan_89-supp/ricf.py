import numpy as np
import scipy.optimize as sopt
import pandas as pd
from ananke.graphs import ADMG


def least_squares_loss(params, X, Z, var_index):

    n, d = X.shape
    return 0.5 / n * np.linalg.norm(X[:, var_index] - np.dot(X, params[0:d]) - np.dot(Z, params[d:])) ** 2


def least_squares_loss_ig(params, X, Z, var_index):

    n, d = X.shape
    return 0.5 / n * np.linalg.norm(X[:, var_index] - np.dot(X, params[0:d]) - np.dot(Z, params[d:2*d]) - np.dot(X, params[2*d:]))


def ricf(data, G, tol=1e-4):
    """
    Perform RICF given data and a graph.

    :param data: pandas data frame
    :param G: Ananke ADMG
    :return: W1, W2 corresponding to directed edge and bidirected edge coefficients
    """

    X = data.values.copy()
    n, d = X.shape
    W1 = np.zeros((d, d))
    W2 = np.zeros((d, d))
    Wii = np.eye(d)

    # just code to ensure zeros appear in the correct places when optimizing
    # i.e. we only have parents for parents and siblings of each variable
    idx_var_map = {i: v for i, v in enumerate(data.columns)}
    var_idx_map = {v: i for i, v in enumerate(data.columns)}
    idxs = set(range(d))
    zero_param_directed = {}
    zero_param_bidirected = {}
    for var_index in range(d):

        # get indices of non parents
        parent_idxs = set(var_idx_map[p] for p in G.parents([idx_var_map[var_index]]))
        zero_param_directed[var_index] = idxs - parent_idxs

        # get indices of non siblings
        sibling_idxs = set(var_idx_map[s] for s in G.siblings([idx_var_map[var_index]]))
        zero_param_bidirected[var_index] = idxs - sibling_idxs

    # keep going until desired convergence
    while True:

        W1_old = W1.copy()
        W2_old = W2.copy()
        Wii_old = Wii.copy()

        # iterate over each vertex
        for var_index in range(d):

            # get omega and calculate pseudo variables Zi
            omega = W2 + Wii
            omega_minusi = np.delete(omega, var_index, axis=0)
            omega_minusii = np.delete(omega_minusi, var_index, axis=1)
            omega_minusii_inv = np.linalg.inv(omega_minusii)

            # get epsilon_minusi
            epsilon = X - np.matmul(X, W1)
            epsilon_minusi = np.delete(epsilon, var_index, axis=1)

            # calculate Z_minusi
            Z_minusi = (omega_minusii_inv @ epsilon_minusi.T).T

            # insert a column of zeros to maintain the shape
            Z = np.insert(Z_minusi, var_index, 0, axis=1)

            # set bounds on possible values, get values of the current estimates and solve
            bounds = [(0, 0) if i in zero_param_directed[var_index] else (None, None) for i in range(d)]
            bounds += [(0, 0) if i in zero_param_bidirected[var_index] else (None, None) for i in range(d)]
            sol = sopt.minimize(least_squares_loss, np.zeros(2*d),
                                args=(X, Z, var_index),
                                method='L-BFGS-B',
                                options={'disp': False}, bounds=bounds)

            # update W1, W2 with the new solution
            W1[:, var_index] = sol.x[0:d]
            W2[var_index, :] = sol.x[d:]
            W2[:, var_index] = sol.x[d:]
            Wii[var_index, var_index] = np.var(X[:, var_index] - np.dot(X, W1[:, var_index]))

        if np.sum(np.abs(W1_old - W1)) + np.sum(np.abs((W2_old + Wii_old) - (W2 + Wii))) < tol:
            break

    return W1, W2 + Wii


def ricf_immiscible(data, G, tol=1e-4):
    """
    Perform RICF given data and an immiscible graph.

    :param data: pandas data frame
    :param G: Ananke immiscible graph.
    :return: W1, W2, W3 corresponding to directed edge, bidirected, undirected edge coefficients
    """

    X = data.values.copy()
    n, d = X.shape
    W1 = np.zeros((d, d))
    W2 = np.zeros((d, d))
    Wii = np.eye(d)
    W3 = np.zeros((d, d))

    # just code to ensure zeros appear in the correct places when optimizing
    # i.e. we only have parents for parents and siblings of each variable
    idx_var_map = {i: v for i, v in enumerate(data.columns)}
    var_idx_map = {v: i for i, v in enumerate(data.columns)}
    idxs = set(range(d))
    zero_param_directed = {}
    zero_param_bidirected = {}
    zero_param_undirected = {}

    for var_index in range(d):

        # get indices of non parents
        parent_idxs = set(var_idx_map[p] for p in G.parents([idx_var_map[var_index]]))
        zero_param_directed[var_index] = idxs - parent_idxs

        # get indices of non siblings
        sibling_idxs = set(var_idx_map[s] for s in G.siblings([idx_var_map[var_index]]))
        zero_param_bidirected[var_index] = idxs - sibling_idxs

        # get indices of non neigbours
        neighbor_idxs = set(var_idx_map[s] for s in G.neighbors([idx_var_map[var_index]]))
        zero_param_undirected[var_index] = idxs - neighbor_idxs

    # keep going until desired convergence
    iters = 0
    while True:

        iters += 1
        W1_old = W1.copy()
        W2_old = W2.copy()
        Wii_old = Wii.copy()
        W3_old = W3.copy()

        # iterate over each vertex
        for var_index in range(d):

            # get omega and calculate pseudo variables Zi
            omega = W2 + Wii
            omega_minusi = np.delete(omega, var_index, axis=0)
            omega_minusii = np.delete(omega_minusi, var_index, axis=1)
            omega_minusii_inv = np.linalg.inv(omega_minusii)

            # get epsilon_minusi
            epsilon = X - np.matmul(X, W1) - np.matmul(X, W3)
            epsilon_minusi = np.delete(epsilon, var_index, axis=1)

            # calculate Z_minusi
            Z_minusi = (omega_minusii_inv @ epsilon_minusi.T).T

            # insert a column of zeros to maintain the shape
            Z = np.insert(Z_minusi, var_index, 0, axis=1)

            # set bounds on possible values, get values of the current estimates and solve
            bounds = [(0, 0) if i in zero_param_directed[var_index] else (None, None) for i in range(d)]
            bounds += [(0, 0) if i in zero_param_bidirected[var_index] else (None, None) for i in range(d)]
            bounds += [(0, 0) if i in zero_param_undirected[var_index] else (None, None) for i in range(d)]
            sol = sopt.minimize(least_squares_loss_ig, np.zeros(3*d),
                                args=(X, Z, var_index),
                                method='L-BFGS-B',
                                options={'disp': False}, bounds=bounds)

            # update W1, W2 with the new solution
            W1[:, var_index] = sol.x[0:d]
            W2[var_index, :] = sol.x[d:2*d]
            W2[:, var_index] = sol.x[d:2*d]
            W3[var_index, :] = sol.x[2*d:]
            W3[:, var_index] = sol.x[2*d:]
            Wii[var_index, var_index] = np.var(X[:, var_index] - np.dot(X, W1[:, var_index]) - np.dot(X, W3[:, var_index]))

        if np.sum(np.abs(W1_old - W1)) + np.sum(np.abs((W2_old + Wii_old) - (W2 + Wii)) + np.sum(np.abs(W3_old - W3))) < tol:
            break

    return W1, W2 + Wii, W3


def main():

    np.random.seed(0)
    size = 5000
    dim = 4
    # generate data from A->B->C->D, A<->D, A<->C
    beta = np.array([[0, 1.2, 0, 0],
                     [0, 0, -1.5, 0],
                     [0, 0, 0, 1.0],
                     [0, 0, 0, 0]]).T

    omega = np.array([[1.2, 0, 0.5, 0.6],
                      [0, 1, 0, 0.],
                      [0.5, 0, 1, 0],
                      [0.6, 0., 0, 1]])

    true_sigma = np.linalg.inv(np.eye(dim) - beta) @ omega @ np.linalg.inv((np.eye(dim) - beta).T)
    X = np.random.multivariate_normal([0] * dim, true_sigma, size=size)
    X = X - np.mean(X, axis=0)  # centre the data
    data = pd.DataFrame({'A': X[:, 0], 'B': X[:, 1], 'C': X[:, 2], 'D': X[:, 3]})

    # make Ananke ADMG and call RICF
    G = ADMG(vertices=['A', 'B', 'C', 'D'],
             di_edges=[('A', 'B'), ('B', 'C'), ('C', 'D')],
             bi_edges=[('A', 'D'), ('A', 'C')])
    beta_hat, omega_hat = ricf(data, G)

    print(beta_hat)
    print(omega_hat)
    print(np.allclose(beta, beta_hat.T, atol=0.1), np.allclose(omega, omega_hat, atol=0.1))


if __name__ == '__main__':
    main()


