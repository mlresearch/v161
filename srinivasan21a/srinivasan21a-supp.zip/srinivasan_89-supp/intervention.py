# Find difference in average surgery length!

import estimation as es
import numpy as np
from generative_model import state_transition
from copy import copy
import matplotlib as mp
from matplotlib import pyplot

# Compute statistic for target in data
duration = [len(list(es.s_list_all[i])) for i in range(len(es.s_list_all))]
np.mean(duration)
# np.std(duration)

# For each datapoint, simulate "n" trains using model params and intervention
n = 5

# Lists to hold values from all iterations of all trials
s_all_plus = []
v_all_plus = []
s_all_minus = []
v_all_minus = []

ix_dict = {'A1': 0, 'B1': 1, 'C1': 2, 'A2': 3, 'B2': 4, 'C2': 5}
for case_number in range(len(es.s_list_all)):
    print(case_number)
    for n_iter in range(n):     # number of iterations for each case
        s_lt_p = [es.s_list_all[case_number][0]]  # first state of data trial
        s_lt_m = [es.s_list_all[case_number][0]]

        v_lt_p = [copy(es.v_list_all[case_number][0])]  # first set of variable values
        v_lt_m = [copy(es.v_list_all[case_number][0])]  # first set of variable values

        # intervention:
        v_lt_p[0][1] += 1
        v_lt_m[0][1] -= 1

        while s_lt_p[-1] not in es.abs_st:
            # Values right now
            s_p = s_lt_p[-1]
            v_p = v_lt_p[-1]

            # Generate new state
            s_new_p = state_transition(curr_state=s_p, prev_var=v_p, p_st=es.p_st_est)    #TODO: Why on earth is it returning an array instead of a scalar!

            # Compute new variable values and append:
            v_temp = [*v_p, 0, 0, 0]
            # Updating A2, B2, C2:
            # step 1: generate "random part" using covariance matrix
            # step 2: generate mean using parents and add random part
            cov_matrix_p = es.omega_hat[(s_new_p, s_p)][[[ix_dict["A2"]], [ix_dict["B2"]], [ix_dict["C2"]]],
                                     [ix_dict["A2"], ix_dict["B2"], ix_dict["C2"]]]
            rd_p = np.random.multivariate_normal([0, 0, 0], cov_matrix_p, 1)
            rd_p = np.concatenate((np.zeros(3), rd_p), axis=None)

            for node in ['A2', 'B2', 'C2']:
                val = np.dot(es.beta_hat[(s_new_p, s_p)][:, ix_dict[node]], v_temp) + rd_p[ix_dict[node]]
                v_temp[ix_dict[node]] = val
            v_new_p = v_temp[len(v_temp) // 2:]

            # intervention:
            v_new_p[1] += 1

            # Concatenate all results so far
            s_lt_p.append(s_new_p)
            v_lt_p.append(v_new_p)

        while s_lt_m[-1] not in es.abs_st:
            # Values right now
            s_m = s_lt_m[-1]
            v_m = v_lt_m[-1]

            # Generate new state
            s_new_m = state_transition(curr_state=s_m, prev_var=v_m,
                                       p_st=es.p_st_est)  # TODO: Why on earth is it returning an array instead of a scalar!

            # Compute new variable values and append:
            v_temp = [*v_m, 0, 0, 0]
            # Updating A2, B2, C2:
            # step 1: generate "random part" using covariance matrix
            # step 2: generate mean using parents and add random part
            cov_matrix_m = es.omega_hat[(s_new_m, s_m)][[[ix_dict["A2"]], [ix_dict["B2"]], [ix_dict["C2"]]],
                                                        [ix_dict["A2"], ix_dict["B2"], ix_dict["C2"]]]
            rd_m = np.random.multivariate_normal([0, 0, 0], cov_matrix_m, 1)
            rd_m = np.concatenate((np.zeros(3), rd_m), axis=None)

            for node in ['A2', 'B2', 'C2']:
                val = np.dot(es.beta_hat[(s_new_m, s_m)][:, ix_dict[node]], v_temp) + rd_m[ix_dict[node]]
                v_temp[ix_dict[node]] = val
            v_new_m = v_temp[len(v_temp) // 2:]

            # intervention:
            v_new_m[1] -= 1

            # Concatenate all results so far
            s_lt_m.append(s_new_m)
            v_lt_m.append(v_new_m)

        s_all_minus.append(s_lt_m)
        v_all_minus.append(v_lt_m)

        s_all_plus.append(s_lt_p)
        v_all_plus.append(v_lt_p)


dp = [len(list(s_all_plus[i])) for i in range(len(s_all_plus))]
np.mean(dp)

dm = [len(list(s_all_minus[i])) for i in range(len(s_all_minus))]
np.mean(dm)

print("mean for attending: ", np.mean(dm))
print("05-quantile:", np.quantile(dm, 0.05))
print("95-quantile:", np.quantile(dm, 0.95))
print("mean for resident: ", np.mean(dp))
print("05-quantile:", np.quantile(dp, 0.05))
print("95-quantile:", np.quantile(dp, 0.95))

# Plot results
bins = np.linspace(0, 35, 36)

pyplot.figure(figsize=(7.5, 2.5))
pyplot.hist(dm,  alpha=0.5, label='Experienced', density=True, bins=bins-0.5)
pyplot.hist(dp, alpha=0.5, label='Trainee', density=True, bins=bins-0.5)
pyplot.legend(loc='upper right', fontsize=15)
pyplot.ylabel('Proportion of\nsurgeries', fontsize=16)
pyplot.xlabel('Length of surgery', fontsize=16)
pyplot.xlim([0,35])
ax = pyplot.gca()
ax.tick_params(axis='both', which='major', labelsize=14)
pyplot.tight_layout()
pyplot.show()

