from ananke.graphs import ADMG
import numpy as np
from scipy.special import expit
import os

########################################################################################################################
# MODEL
########################################################################################################################
# Basic params
K = 3   # number of possible states of the system: {0,1,2}
M = 3   # number of variables in each state: assume observed variables are the same across states
abs_st = [2]    # list of absorbing states

########################################################################################################################
# ADMG representation for states

state_admg_dict = {}
state_admg_dict[0] = ADMG(vertices=['A', 'B', 'C'],
                          di_edges=[('A', 'B'), ('B', 'C')],
                          bi_edges=[])
state_admg_dict[1] = ADMG(vertices=['A', 'B', 'C'],
                          di_edges=[('A', 'C'), ('B', 'C')],
                          bi_edges=[('A', 'B')])
state_admg_dict[2] = ADMG(vertices=['A', 'B', 'C'],
                          di_edges=[('A', 'B'), ('A', 'C')],
                          bi_edges=[])

########################################################################################################################
# ADMG representation for transition graphs
# Key: (s_t+1, s_t)
# conditional graph, without edges in previous timestep
transition_admg_dict = {}
transition_admg_dict[(1, 0)] = ADMG(vertices=['A1', 'B1', 'C1', 'A2', 'B2', 'C2'],
                                    di_edges=[('A1', 'A2'), ('C1', 'A2'), ('C1', 'C2'), ('A2', 'C2'), ('B2', 'C2')],
                                    bi_edges=[('A2', 'B2')])
transition_admg_dict[(2, 1)] = ADMG(vertices=['A1', 'B1', 'C1', 'A2', 'B2', 'C2'],
                                    di_edges=[('A1', 'A2'), ('B1', 'B2'), ('C1', 'C2'), ('C1','A2'), ('A2', 'B2'), ('A2', 'C2')],
                                    bi_edges=[])
transition_admg_dict[(0, 1)] = ADMG(vertices=['A1', 'B1', 'C1', 'A2', 'B2', 'C2'],
                                    di_edges=[('A1', 'A2'), ('B1', 'B2'), ('C1', 'C2'), ('A1', 'B2'), ('C1', 'A2'),
                                              ('C1', 'B2'), ('A2', 'B2'), ('B2', 'C2')],
                                    bi_edges=[])

########################################################################################################################

# STATE TRANSITION MATRIX
# Key: (s_t+1, s_t)
# Value: [a, b, c, d] s.t. probability P(s_t+1| s_t, v_0, v_1, v_2) = a*v_0 + b*v_1 + c*v_2 + d

p_st = {}
p_st[(1, 0)] = [1, 0, 0, 0]  # going from state 0 to state 1
p_st[(0, 1)] = [np.random.normal(0, 0.02), -1.5, -0.8, 1.7]  # going from state 1 to state 0


def state_transition(curr_state, prev_var, p_st):
    # TODO: Change name prev_var to curr_var
    # inputs:
    # curr_state: scalar {0,1}      # if state is 2, there is no next state.
    # prev_vars: vector [v0,v1,v2]: 3-dimensional vector of values of variables in prev state
    # output:
    # next_state: scalar {0,1,2}

    if curr_state == 0:
        next_state = 1
    else:
        key = (0, 1)
        temp = prev_var.copy()
        temp.insert(0, 1.)
        next_state = 2 * (np.random.rand() < expit(np.dot(p_st[key], temp))).astype(int)

    return next_state

########################################################################################################################

# Distribution of variables

# Independent noise variance
indep_noise = {}
for transition in [(0, 1), (1, 0), (2, 1)]:
    for var in ['A2', 'B2', 'C2']:
        indep_noise[(var, *transition)] = abs(np.random.normal())

sem_coeffs = {}

sem_coeffs[('A2', 1, 0)] = {'A1': 0.5, 'C1': -0.3, 'U': 0.5}   # keys are g.parents(['A2']) where g = transition_admg_dict[(1, 0)] + a key for u (the bidirected edge)
sem_coeffs[('B2', 1, 0)] = {'U': 0.5}     # keys are g.parents(['B2']) where g = transition_admg_dict[(1, 0)] + a key for u (the bidirected edge)
sem_coeffs[('C2', 1, 0)] = {'A2': -1.1, 'B2': -0.6, 'C1': -0.7}   # keys are g.parents(['C2']) where g = transition_admg_dict[(1, 0)]

sem_coeffs[('A2', 2, 1)] = {'A1': 0.4, 'C1': 0.8}   # keys are g.parents(['A2']) where g = transition_admg_dict[(2, 1)]
sem_coeffs[('B2', 2, 1)] = {'A2': -0.6, 'B1': 0.3}   # keys are g.parents(['B2']) where g = transition_admg_dict[(2, 1)]
sem_coeffs[('C2', 2, 1)] = {'A2': -0.2, 'C1': -0.7}   # keys are g.parents(['C2']) where g = transition_admg_dict[(2, 1)]

sem_coeffs[('A2', 0, 1)] = {'A1': 0.5, 'C1': -0.3}   # keys are g.parents(['A2']) where g = transition_admg_dict[(0, 1)]
sem_coeffs[('B2', 0, 1)] = {'A2': 0.6, 'A1': 0.06, 'B1': 0.1, 'C1': -0.2}   # keys are g.parents(['B2']) where g = transition_admg_dict[(0, 1)]
sem_coeffs[('C2', 0, 1)] = {'B2': -0.7, 'C1': -0.8}   # keys are g.parents(['C2']) where g = transition_admg_dict[(0, 1)]

#########################################beta_hat, omega_hat = rf.ricf(data, graph)###############################################################################
# DATA GENERATION
########################################################################################################################

N = 10000
s_list_all = []
v_list_all = []
ix_dict = {'A1': 0, 'B1': 1, 'C1': 2, 'A2': 3, 'B2': 4, 'C2': 5}

for sample in range(N):
    s_list = [0]            # everyone starts at this state
    v_list = [[1, 0, 0]]    # everyone starts with these variable values

    while s_list[-1] not in abs_st:
        # values right now
        s = s_list[-1]
        v = v_list[-1]

        # Generate new state and append:
        s_new = state_transition(curr_state = s, prev_var = v, p_st = p_st)

        # Compute new variable values and append:
        v_temp = [*v, 0, 0, 0]
        if s_new == 1:
            u = np.random.normal()
        # Updating A2, B2, C2:
        for node in ['A2', 'B2', 'C2']:
            val = 0
            for parent in sem_coeffs[(node, s_new, s)].keys():
                if parent != 'U':
                    val = val + v_temp[ix_dict[parent]]*sem_coeffs[(node, s_new, s)][parent]
                if parent == 'U':
                    val = val + u*sem_coeffs[(node, s_new, s)][parent]
            val = val + np.random.normal(0, np.sqrt(indep_noise[(node, s_new, s)]))
            v_temp[ix_dict[node]] = val

        v_new = v_temp[len(v_temp)//2:]

        # Concatenate all results so far
        s_list.append(s_new)
        v_list.append(v_new)
    print(sample)
    s_list_all.append(s_list)
    v_list_all.append(v_list)

durations = []
for sample in range(N):
    durations.append(len(s_list_all[sample]))
E = np.mean(durations)

########################################################################################################################
# SAVE THE DATA TO FILE
########################################################################################################################
sim = 2
filename = './sim' + str(sim) + '/data.npz'
os.makedirs(os.path.dirname(filename), exist_ok=True)
np.savez_compressed(filename, v_list_all=np.array(v_list_all, dtype=object), s_list_all=np.array(s_list_all, dtype=object),
                    K=K, M=M, abs_st=abs_st, p_st=p_st, state_dict=state_admg_dict,
                    trans_dict=transition_admg_dict, indep_noise=indep_noise, sem_coeffs=sem_coeffs)
