import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
import ricf as rf

np.random.seed(0)
##################################################################################
## Load Data and Retrieve Params
sim_num = 2
name = './sim' + str(sim_num) + '/data.npz'
data = np.load(name, allow_pickle=True)

# retrieve params - to use in estimation
v_list_all = data["v_list_all"]
s_list_all = data["s_list_all"]
K = data["K"].item()
M = data["M"].item()
abs_st = data["abs_st"]
state_dict = data["state_dict"].item()
trans_dict = data["trans_dict"].item()

# params to compare mle estimate with:
p_st = data["p_st"].item()
indep_noise = data["indep_noise"].item()
sem_coeffs = data["sem_coeffs"].item()

########################################################################################################################
# ESTIMATING STATE TRANSITION PROBABILITIES
########################################################################################################################
# Fit logistic regression on data conditioned on state transitions, .coef_ will give coefficients
data_df = pd.DataFrame()
for sample in range(len(s_list_all)):
    print(sample)
    df = pd.DataFrame({'S': s_list_all[sample],
                       'A1': [v[0] for v in v_list_all[sample]],
                       'B1': [v[1] for v in v_list_all[sample]],
                       'C1': [v[2] for v in v_list_all[sample]]})

    df['S+'] = df['S'].shift(-1)                        # shift to get "next state"
    df['A2'] = df['A1'].shift(-1)  # shift to get "next state"
    df['B2'] = df['B1'].shift(-1)  # shift to get "next state"
    df['C2'] = df['C1'].shift(-1)  # shift to get "next state"

    df.drop(df.tail(1).index, inplace=True)             # remove last row because it doesn't have a "next state"
    data_df = data_df.append(df, ignore_index=True)     # append to main data_df


p_st_est = {}
for name, group in data_df.groupby(['S']):
    X = group[['A1', 'B1', 'C1']]
    X.insert(loc=0, column='intercept', value=1)
    y = group['S+']
    if y.nunique() > 1:
        clf = LogisticRegression(random_state=0).fit(X.values, y.values.ravel())        # TODO: specify solver
        p_st_est[(0, name)] = list(clf.coef_[0])
    elif y.nunique() == 1:
        p_st_est[(int(y.unique()[0]), name)] = [1, 0, 0, 0]

########################################################################################################################
# ESTIMATING PARAMETERS IN NORMALLY DISTRIBUTED VARIABLES
########################################################################################################################

beta_hat = {}
omega_hat = {}
for name, group in data_df.groupby(['S+', 'S']):
    data = group[['A1', 'B1', 'C1', 'A2', 'B2', 'C2']]
    graph = trans_dict[name]
    beta, omega = rf.ricf(data, graph)
    beta_hat[(int(name[0]), name[1])] = beta
    omega_hat[(int(name[0]), name[1])] = omega


