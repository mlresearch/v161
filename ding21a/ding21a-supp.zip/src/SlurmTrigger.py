import os
import sys
import random
import argparse

def walkandInvoke():
        parser = argparse.ArgumentParser(description="Walks through the data folder and triggers parafly script")
        parser.add_argument("-job", type=str, default='network', help="dataset folder")
        parser.add_argument('-q', '--queue', type=str, default="yexiang", help="slurm queue")
        args = parser.parse_args()
        outdir = "/home/ding274/CSO/src/%sdata/model/" % (args.job.lower())

        for filename in ['weak_20', 'strong_20', 'weak_81', 'strong_81']:
                command = "python runSlurm.py {} {} -job {} --queue {}".format(filename, outdir, args.job, args.queue)
                print(command)
                os.system(command)

if __name__ == "__main__":
    walkandInvoke()


##  python runSlurm.py strong_20 /home/ding274/CSO/src/networkdata/model/ -job network --queue yexiang