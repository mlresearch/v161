import os
import numpy as np 
import matplotlib.pyplot as plt
import argparse
import scipy.io as scio

def convert():
    fname = 'strong_20'
    f = open(fname+'_edge.txt', 'r')
    line=f.readline()
    m, n = line.split('\t')
    m = int(m)//2
    newline = str(m) + '\t' + n
    lines = []
    lines.append(newline)
    while(line):
        print(line)
        print(len(lines))
        line=f.readline()
        if (not line):
            break
        frtovar = line.split('\t')[:-1]
        fr, to, var = list(map(int, frtovar))
        if fr<to:
            gi = np.abs(1 + np.random.randn(1))[0]
            newline = '\t'.join(frtovar) + '\t%.3f\n' % (gi)
            lines.append(newline)

    f.close()

    f = open(fname+'_newedge.txt', 'w')
    for line in lines:
        f.write(line)
    f.close()

def paint(file, prob_Gibbs, prob_BP, prob_BPCD, prob_XOR):
    plt.figure(figsize=(12,9))
    x = np.linspace(1,4,4).astype(int)
    width=0.3
    # plt.plot(x, prob_Gibbs, 'r--o', label='Gibbs',linewidth=3, markersize=18)
    # # plt.plot(x, prob_BP, 'b--s', label='BP-CD',linewidth=3, markersize=18)
    # plt.plot(x, prob_XOR, 'g--d', label='XOR',linewidth=3, markersize=18)
    plt.bar(x-width, 100*(1-prob_XOR/prob_Gibbs), width=width, label="savings/Gibbs")
    plt.bar(x, 100*(1-prob_XOR/prob_BP), width=width, label="savings/BP")
    plt.bar(x+width, 100*(1-prob_XOR/prob_BPCD), width=width, color='c', label="savings/BPChain")
    plt.xlabel('Networks',fontsize=40)
    plt.ylabel('Percentage of savings',fontsize=40)
    # plt.xlim([10,31])
    xstick = ['weak,20', 'strong,20', 'weak,80', 'strong,80']
    plt.xticks(x, xstick)
    plt.xticks(fontsize=30)
    ax = plt.gca()
    ax.set_yticks([0,2,4,6,8,10,12])
    ystick = ['0%', '2%', '4%', '6%', '8%', '10%', '12%']
    ax.set_yticklabels(ystick)
    plt.yticks(fontsize=30)
    plt.grid()
    plt.legend(fontsize=30)
    # plt.savefig('figs/' + file + '.pdf')
    plt.show()

def paint1(file, prob_Gibbs, prob_BP, prob_BPCD, prob_XOR):
    plt.figure(figsize=(12,9))
    x = np.linspace(1,10,10).astype(int)
    plt.plot(x, prob_Gibbs, 'r--o', label='Gibbs',linewidth=3, markersize=18)
    plt.plot(x, prob_BP, 'b--s', label='BP',linewidth=3, markersize=18)
    plt.plot(x, prob_BPCD, 'c--^', label='BPChain',linewidth=3, markersize=18)
    plt.plot(x, prob_XOR, 'g--d', label='XOR',linewidth=3, markersize=18)
    plt.xlabel('Budget size (%)',fontsize=40)
    plt.ylabel('Commuting Time (x$10^4$)',fontsize=40)
    # plt.xlim([10,31])
    xstick = ['10', '20', '30', '40', '50', '60', '70', '80', '90', '100']
    plt.xticks(x, xstick)
    plt.xticks(fontsize=30)
    plt.yticks(fontsize=30)
    plt.grid()
    plt.legend(fontsize=40)
    # plt.savefig('figs/' + file + '.pdf')
    plt.show()

def paint2(file, prob_Gibbs, prob_BP, prob_BPCD, prob_XOR):
    fig, ax = plt.subplots(nrows=2, ncols=1, figsize=(12, 9))
    x = np.linspace(1,8,8).astype(int)
    x0 = np.array([1,1.25,1.5,1.75,2,2.15,2.2,2.25])
    ax[0].plot(x, prob_Gibbs, 'r--o', label='Gibbs',linewidth=3, markersize=18)
    ax[0].plot(x, prob_BP, 'b--s', label='BP',linewidth=3, markersize=18)
    ax[0].plot(x, prob_BPCD, 'c--^', label='BPChain',linewidth=3, markersize=18)
    ax[0].plot(x0, prob_XOR, 'g--d', label='XOR',linewidth=3, markersize=18)
    xstick1 = ['20', '100', '500', '1000', '5000', '10000', '15000', '20000']
    ax[0].set_xticks(x)
    ax[0].set_xticklabels(xstick1)
    ax[0].tick_params(axis="x", labelsize=30)
    ax[0].tick_params(axis="y", labelsize=30)
    ax[0].grid()
    ax[0].legend(fontsize=30, loc='upper right')
    ax[1].plot(x, prob_XOR, 'g--d', label='XOR',linewidth=3, markersize=18)
    xstick2 = ['20', '40', '60', '80', '100', '120', '140', '160']
    ax[1].set_xticks(x)
    ax[1].set_xticklabels(xstick2)
    ax[1].tick_params(axis="x", labelsize=30)
    ax[1].tick_params(axis="y", labelsize=30)
    ax[1].grid()
    ax[1].legend(fontsize=30)
    plt.xlabel('Number of samples',fontsize=40)
    fig.text(0.01, 0.5, 'Commuting Time (x$10^4$)', va='center', rotation='vertical',fontsize=40)
    plt.show()

def paint_in(file, prob_Gibbs, prob_BP, prob_BPCD, prob_XOR):
    plt.figure(figsize=(12,9))
    x = np.linspace(1,10,10).astype(int)
    width = 0.3
    # plt.plot(x, prob_Gibbs, 'r--o', label='Gibbs',linewidth=3, markersize=18)
    # plt.plot(x, prob_BP, 'b--s', label='BP-CD',linewidth=3, markersize=18)
    # plt.plot(x, prob_XOR, 'g--d', label='XOR',linewidth=3, markersize=18)
    plt.bar(x-width, 100*(1-prob_XOR/prob_Gibbs), width=width, label="savings/Gibbs")
    plt.bar(x, 100*(1-prob_XOR/prob_BP), width=width, label="savings/BP")
    plt.bar(x+width, 100*(1-prob_XOR/prob_BPCD), width=width, color='c', label="savings/BPChain")
    plt.xlabel('Number of materials',fontsize=40)
    # plt.ylabel('$E_{\\theta\sim p(\\theta)}G(x,d;\\theta)$ x($10^2)$',fontsize=30)
    plt.ylabel('Percentage of savings', fontsize=40)
    # plt.xlim([10,31])
    xstick = ['10', '20', '30', '40', '50', '60', '70', '80', '90', '100']
    plt.xticks(x, xstick)
    plt.xticks(fontsize=30)
    ax = plt.gca()
    ax.set_yticks([0,5,10,15,20,25])
    ystick = ['0%', '5%', '10%', '15%', '20%', '25%']
    ax.set_yticklabels(ystick)
    plt.yticks(fontsize=30)
    plt.grid()
    plt.legend(fontsize=30)
    # plt.savefig('figs/' + file + '.pdf')
    plt.show()

def paint_in1(file, prob_Gibbs, prob_BP, prob_BPCD, prob_XOR):
    fig = plt.figure(figsize=(12,9))
    x = np.linspace(1,10,10).astype(int)
    plt.plot(x, prob_Gibbs, 'r--o', label='Gibbs',linewidth=3, markersize=18)
    plt.plot(x, prob_BP, 'b--s', label='BP',linewidth=3, markersize=18)
    plt.plot(x, prob_BPCD, 'c--^', label='BPChain',linewidth=3, markersize=18)
    plt.plot(x, prob_XOR, 'g--d', label='XOR',linewidth=3, markersize=18)
    plt.xlabel('Storage limit (%)',fontsize=40)
    # plt.ylabel('Expectation of total cost (x$10^2)$',fontsize=40)
    fig.text(0.01, 0.5, 'Expectation of total cost (x$10^2)$', va='center', rotation='vertical',fontsize=40)
    # plt.xlim([10,31])
    xstick = ['10', '20', '30', '40', '50', '60', '70', '80', '90', '100']
    plt.xticks(x, xstick)
    plt.xticks(fontsize=30)
    plt.yticks(fontsize=30)
    plt.grid()
    plt.legend(fontsize=40)
    # plt.savefig('figs/' + file + '.pdf')
    plt.show()

def paint_in2(file, prob_Gibbs, prob_BP, prob_BPCD, prob_XOR):
    fig, ax = plt.subplots(nrows=2, ncols=1, figsize=(12, 9))
    x = np.linspace(1,8,8).astype(int)
    x0 = np.array([1,1.25,1.5,1.75,2,2.15,2.2,2.25])
    ax[0].plot(x, prob_Gibbs, 'r--o', label='Gibbs',linewidth=3, markersize=18)
    ax[0].plot(x, prob_BP, 'b--s', label='BP',linewidth=3, markersize=18)
    ax[0].plot(x, prob_BPCD, 'c--^', label='BPChain',linewidth=3, markersize=18)
    ax[0].plot(x0, prob_XOR, 'g--d', label='XOR',linewidth=3, markersize=18)
    xstick1 = ['20', '100', '500', '1000', '5000', '10000', '15000', '20000']
    ax[0].set_xticks(x)
    ax[0].set_xticklabels(xstick1)
    ax[0].tick_params(axis="x", labelsize=30)
    ax[0].tick_params(axis="y", labelsize=30)
    ax[0].grid()
    ax[0].legend(fontsize=30, loc='upper right')
    ax[1].plot(x, prob_XOR, 'g--d', label='XOR',linewidth=3, markersize=18)
    xstick2 = ['20', '40', '60', '80', '100', '120', '140', '160']
    ax[1].set_xticks(x)
    ax[1].set_xticklabels(xstick2)
    ax[1].tick_params(axis="x", labelsize=30)
    ax[1].tick_params(axis="y", labelsize=30)
    ax[1].grid()
    ax[1].legend(fontsize=30)
    plt.xlabel('Number of samples',fontsize=40)
    fig.text(0.01, 0.5, 'Expectation of total cost (x$10^2)$', va='center', rotation='vertical',fontsize=40)
    plt.show()

if __name__=='__main__':
    ## network
    network = 0
    budget = 0
    sample = 0
    if network:
        file = 'networks'
        prob_Gibbs = np.array([0.37, 0.60, 1.98, 2.24])
        prob_BP = np.array([0.39, 0.611, 2.05, 2.28])
        prob_BPCD = np.array([0.363, 0.586, 2.01, 2.26])
        prob_XOR  = np.array([0.34, 0.54, 1.81, 2.11])
        paint(file,  prob_Gibbs, prob_BP, prob_BPCD, prob_XOR)
    
    if budget:
        file = 'network_budget'
        prob_Gibbs = np.array([0.58, 0.53, 0.49, 0.45, 0.43, 0.40, 0.38, 0.37, 0.37, 0.37])
        prob_BP = np.array([0.56, 0.54, 0.51, 0.448, 0.43, 0.42, 0.41, 0.41, 0.40, 0.39])
        prob_BPCD = np.array([0.53, 0.523, 0.477, 0.415, 0.397, 0.381, 0.373, 0.368, 0.365, 0.363])
        prob_XOR  = np.array([0.49, 0.45, 0.42, 0.39, 0.38, 0.36, 0.35, 0.34, 0.34, 0.34])
        paint1(file, prob_Gibbs, prob_BP, prob_BPCD, prob_XOR)
    
    if sample:
        file = 'network_sample'
        prob_Gibbs = np.array([0.4228, 0.3834, 0.3774, 0.3753, 0.3715, 0.3703, 0.3696, 0.3693])
        prob_BP = np.array([0.4345, 0.4143, 0.4047, 0.3935, 0.3909, 0.3902, 0.3901, 0.3888])
        prob_BPCD = np.array([0.4005, 0.3693, 0.3641, 0.3633, 0.3635, 0.3632, 0.3627, 0.3623])
        prob_XOR  = np.array([0.385, 0.352, 0.343, 0.342, 0.341, 0.339, 0.342, 0.338])
        paint2(file, prob_Gibbs, prob_BP, prob_BPCD, prob_XOR)

    ## inventory
    inventory = 1
    budget_in = 0
    gap_in = 0
    if inventory:
        file = 'inventory'
        prob_Gibbs = np.array([0.14, 0.28, 0.35, 0.55, 0.67, 0.81, 0.94, 1.06, 1.19, 1.25])
        prob_BP = np.array([0.166, 0.285, 0.366, 0.585, 0.712, 0.844, 0.977, 1.22, 1.42, 1.52])
        prob_BPCD = np.array([0.137, 0.262, 0.345, 0.541, 0.631, 0.818, 0.952, 1.13, 1.31, 1.44])
        prob_XOR  = np.array([0.13, 0.23, 0.32, 0.49, 0.58, 0.72, 0.85, 0.94, 1.04, 1.11])
        paint_in(file,  prob_Gibbs, prob_BP, prob_BPCD, prob_XOR)
    
    if budget_in:
        file = 'inventory_budget'
        prob_Gibbs = np.array([0.951, 0.901, 0.853, 0.808, 0.765, 0.733, 0.696, 0.684, 0.676, 0.672])
        prob_BP = np.array([0.964, 0.943, 0.863, 0.858, 0.825, 0.773, 0.767, 0.754, 0.747, 0.712])
        prob_BPCD = np.array([0.927, 0.862, 0.806, 0.774, 0.748, 0.725, 0.689, 0.659, 0.641, 0.631])
        prob_XOR  = np.array([0.839, 0.803, 0.757, 0.713, 0.668, 0.622, 0.602, 0.583, 0.584, 0.582])
        paint_in1(file,  prob_Gibbs, prob_BP, prob_BPCD, prob_XOR)
    
    if gap_in:
        file = 'inventory_gap'
        prob_Gibbs = np.array([0.825, 0.692, 0.679, 0.677, 0.6768, 0.6766, 0.6765, 0.6762])
        prob_BP = np.array([0.8329, 0.7812, 0.7339, 0.7191, 0.7186, 0.712, 0.7119, 0.7116])
        prob_BPCD = np.array([0.7814, 0.6521, 0.6421, 0.6374, 0.6354, 0.6332, 0.6356, 0.6326])
        prob_XOR  = np.array([0.744, 0.679, 0.642, 0.601, 0.582, 0.578, 0.575, 0.572])
        paint_in2(file,  prob_Gibbs, prob_BP, prob_BPCD, prob_XOR)


    
