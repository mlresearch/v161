# import torch
# import torch.nn as nn
# from torch.autograd import Variable
# import torch.optim as optim
import numpy as np
from scipy import stats
from numpy.linalg import inv
import scipy.io as scio
import scipy.stats as st
import argparse
import copy
import math
import os 
import sys
from pyGM.messagepass import LBP
from pyGM.graphmodel import GraphModel, eliminationOrder
from pyGM.factor import Factor
from loaduai import readUai, writeUai
from AceSample import log10partition

class MRF(GraphModel):
	def __init__(self, factors, dims, filename):
		super(MRF, self).__init__(factorList=factors)
		# self.factors = factors
		self.dims = dims
		self.filename = filename
	
	def Exact_Sampling(self, n_samples):  # Exactly Sample Uai file using Ace #######
		a = np.ones([n_samples, self.dims], dtype=int)
		for sam in range(n_samples):
			logZ = log10partition(self.filename)
			model = GraphModel(self.factors)
			for xi in range(self.dims):
				for f in model.factors:
					f.t[np.where(f.t==0)] = 1e-5
				model1 = GraphModel(model.factors)
				model1.condition2([xi], [1])
				for f in model1.factors:
					f.t[np.where(f.t==0)] = 1e-5
				writeUai('%spartition1.uai' % (self.filename[:-4]), model1.factors)
				logZ1 = log10partition('%spartition1.uai' % (self.filename[:-4]))
				# print('sam:[%d],xi:[%d]' % (sam,xi))
				# print('logZ:',logZ)
				# print('logZ1:',logZ1)
				p1 = np.clip(np.power(10, logZ1-logZ), 0, 1)
				v = np.random.binomial(1, p1, 1)[0]
				# print('v:',v)
				a[sam][xi] = v
				if (v == 1):
					logZ = logZ1
					model = model1
				elif (v == 0):
					logZ = np.log10(1-p1) + logZ
					model0 = GraphModel(model.factors)
					model0.condition2([xi], [0])
					model = model0
		return a
	
	def XOR_Sampling(self, n_samples):   ##  Sample Uai file using PAWS
		nbauxv = 20
		term = []
		while len(term)!=n_samples:
			os.system('./paws {} -paritylevel 1 -samples {} -nbauxv {} -b 7 -alpha 1 -pivot 4 > tmp.txt'.format(self.filename, n_samples, nbauxv))
			with open('forsample.txt', 'r') as f:
				while(True):
					line=f.readline()
					if(len(line)==0 or len(term)==n_samples):
						break
					line = line[:self.dims]
					term.append(list(line))
		a=np.asarray(term, dtype=int)
		return a

	def Gibbs_Sampling(self, n_samples, initials=None, stopSamples=1):
		"""Gibbs sampling procedure for discrete graphical model "model"
		"""
		# state = state if state is not None else [np.random.randint(Xi.states) for Xi in self.X]
		# TODO: timing check
		if initials == None:
			term = np.random.binomial(1,0.5, size=(n_samples, self.dims))
		else:
			term = copy.deepcopy(initials)

		for sam in range(n_samples):
			for j in range(stopSamples):
				# TODO if out of time, break
				for Xi in self.X:
					p = Factor([],1.0)
					for f in self.factorsWith(Xi,False):
						cvar = f.vars - [Xi]
						p *= f.condition2( cvar, [term[sam][v] for v in cvar] )
					p /= p.sum()
					term[sam][Xi] = p.sample()[0]
		return term
	
	def Belief_Propagation(self, n_samples):
		term = np.ones((n_samples, self.dims), dtype=int)
		belief_V = LBP(self, maxIter=10, verbose=False)
		for sam in range(n_samples):
			for i, x_p in enumerate(belief_V):
				term[sam][i] = x_p.sample()[0]
		return term
	
	def Conditional_Belief_Propagation(self, n_samples):
		term = np.ones((n_samples, self.dims), dtype=int)
		for sam in range(n_samples):
			modelA = GraphModel(self.factors)
			for i in range(self.dims):
				belief_V = LBP(modelA, maxIter=10, verbose=False)
				# print('belief_V:', [f.t for f in belief_V])
				one_sample = belief_V[self.dims-1-i].sample()[0]
				# print('[dim %d]_sample:' % (i), one_sample)
				term[sam][self.dims-1-i] = one_sample
				modelA.condition2([self.dims-1-i], [one_sample])
				modelA.removeFactors(modelA.factorsWith(self.dims-1-i))
				modelA = GraphModel(modelA.factors)
				for f in modelA.factors:
					f.t[np.where(f.t==0)] = 1e-5
				# print('modelA:', modelA.X)
				# print([(f.v, f.t) for f in modelA.factors])
		return term

	def Sampling(self, method, n_samples, initials=None):
		if method == 'gibbs':
			samples = self.Gibbs_Sampling(n_samples, initials)
		elif method == 'bp':
			samples = self.Belief_Propagation(n_samples)
		elif method == 'xor':
			samples = self.XOR_Sampling(n_samples)
		elif method == 'exact':
			samples = self.Exact_Sampling(n_samples)
		else:
			print("WRONG TO SAMPLE!")
		return samples