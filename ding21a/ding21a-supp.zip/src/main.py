# import torch
# import torch.nn as nn
# from torch.autograd import Variable
# import torch.optim as optim
import numpy as np
from scipy import stats
from numpy.linalg import inv
import scipy.io as scio
import scipy.stats as st
import argparse
import copy
import math
import os 
import sys
from pyGM.messagepass import LBP
from pyGM.graphmodel import GraphModel, eliminationOrder
from pyGM.factor import Factor
from AceSample import log10partition
from mrf import MRF
from loaduai import readUai, writeUai

BUDGET = 10
NUM_EPOCHS = 1000
NUM_SAMPLES = 100
NUM_SAMPLES_XOR = 100
NUM_SAMPLES_GIBBS = 10000
LAMDA = 0.1

class Conductance():
	def __init__(self, g, method):
		super(Conductance, self)
		self.g = g
		self.langrange = 1.0
		self.method = method
	
	def Get_g(self):
		return self.g

	def Update_g(self, lamda, grad_r, grad_l):
		self.g -= lamda * grad_r
		self.g = np.clip(self.g, 0, BUDGET)
		self.langrange -= grad_l
		self.langrange = np.clip(self.langrange, 0, np.infty)

class NetWork():
	def __init__(self, name):
		super(NetWork, self)
		self.name = name
		self.uainame = name + '_subtree.uai'
		self.edgename = name + '_newedge.txt'
		factors, dims = readUai(self.uainame)
		self.mrf = MRF(factors, dims, self.uainame)
		self.initialize()
		self.one = np.ones((self.n, 1))
		self.ones = np.matmul(self.one, self.one.T)
	
	def initialize(self):
		f = open(self.edgename, 'r')
		m, n = f.readline().split('\t')
		self.m = int(m)
		self.n = int(n)
		self.g = np.ones(self.m) / self.m
		self.A = np.zeros((self.n, self.m))
		self.table = []
		idx = 0
		mrf_idx = 0
		for i in range(self.m):
			line = f.readline().split('\t')
			fr, to, var = list(map(int, line[:-1]))
			gi = float(line[-1])
			self.g[idx] = gi
			self.A[fr][idx] = 1
			self.A[to][idx] = -1
			if var == mrf_idx:
				self.table.append(idx)
				mrf_idx += 1
			idx += 1
		
		self.table = np.array(self.table)
		self.L = np.matmul( np.matmul(self.A, np.diag(self.g)), self.A.T)

	def R_tot(self, conductance, samples, n_samples):
		r_tot = 0
		for i in range(len(samples)):
			sample = samples[i]
			idxs = self.table[np.where(sample == 0)]
			g = conductance.Get_g()
			g[idxs] = 1e-5
			L = np.matmul( np.matmul(self.A, np.diag(g)), self.A.T)
			try:
				r = self.n * np.trace( np.linalg.inv(L + self.ones/self.n) ) - self.n
			except:
				print('L+1/n: ', L+self.ones/self.n)
			r_tot += r * 4 * np.sum(g) / (self.n * (self.n-1) )
		return r_tot / n_samples

	def Grad_R_tot(self, conductance, n_samples):
		grad_r_tot = 0
		samples = self.mrf.Sampling(conductance.method, n_samples)
		print('sample.shape:', samples.shape)
		grad_l_tot = - (np.sum(conductance.Get_g()) - BUDGET)
		for i in range(len(samples)):
			sample = samples[i]
			# print('sample:',sample)
			idxs = self.table[np.where(sample == 0)]
			g = conductance.Get_g()
			g[idxs] = 1e-5
			L = np.matmul( np.matmul(self.A, np.diag(g)), self.A.T)
			try:
				grad_r = -self.n * np.diag( np.matmul( np.matmul( self.A.T, np.linalg.matrix_power(L+self.ones/self.n, -2) ), self.A) ) + conductance.langrange
			except:
				print('L+1/n: ', L+self.ones/self.n)
			grad_r[idxs] = conductance.langrange
			# print('grad_r:',grad_r)
			grad_r_tot += grad_r
		return grad_r_tot / n_samples, grad_l_tot

if __name__=='__main__':
	parser = argparse.ArgumentParser(description='Convex Stochastic Optimization')
	parser.add_argument('--name',default='weak_81', help='name must be specified')
	parser.add_argument("--job", type=str, default='network', help="dataset folder")
	args = parser.parse_args()
	name = args.name
	print(name)

	network = NetWork(name)
	conductance_gibbs = Conductance(network.g, 'gibbs')
	conductance_xor   = Conductance(network.g, 'xor')

	print('n:', network.n)
	print('m:', network.m)
	# print('A:', network.A)
	# print('L:', network.L)
	# print('table:', network.table)
	# print('gibbs g:', conductance_gibbs.Get_g())
	# print('xor g:', conductance_xor.Get_g())
	
	losses = []
	print("Generate exact samples for testing:\n")
	samples = network.mrf.Sampling('exact', 10*NUM_SAMPLES)
	samples = []
	for epoch in range(NUM_EPOCHS):
		print('epoch [{}/{}]'.format(epoch, NUM_EPOCHS))
		
		if epoch % 10 == 9:
			# compare R_tot
			gibbs_tot = network.R_tot(conductance_gibbs, samples, 10*NUM_SAMPLES)
			print('R_tot:\t[gibbs]:\t' + str(gibbs_tot))
			xor_tot = network.R_tot(conductance_xor, samples, 10*NUM_SAMPLES)
			print('R_tot:\t[xor]:\t' + str(xor_tot))

			loss = "epoch [{}/{}]:\n\tgibbs:{}\txor:\t{}\n".format(epoch, NUM_EPOCHS, gibbs_tot, xor_tot)
			losses.append(loss)
			with open("{}_results".format(name), 'w') as f:
				f.write(loss)
		
		# adjust learning rate
		if epoch > 50:
			lamda = LAMDA / 10
		elif epoch > 150:
			lamda = LAMDA / 100
		else:
			lamda = LAMDA
		# learning one iteration
		print('[gibbs]:')
		grad_r, grad_l = network.Grad_R_tot(conductance_gibbs, NUM_SAMPLES_GIBBS)
		conductance_gibbs.Update_g(lamda, grad_r, grad_l)
		print('[xor]:')
		grad_r, grad_l = network.Grad_R_tot(conductance_xor, NUM_SAMPLES_XOR)
		conductance_xor.Update_g(lamda, grad_r, grad_l)

		## print conductance
		# print('gibbs g:', conductance_gibbs.Get_g())
		# print('xor g:', conductance_xor.Get_g())

		with open("{}.LOG".format(name), 'w') as f:
			for line in losses:
				f.write(line)

	# print conductance
	print('gibbs g:', conductance_gibbs.Get_g())
	print('gibbs langrange:', conductance_gibbs.langrange)
	print('xor g:', conductance_xor.Get_g())
	print('xor langrange:', conductance_xor.langrange)
		





