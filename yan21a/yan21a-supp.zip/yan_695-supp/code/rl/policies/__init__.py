from rl.core.function_approximators.policies import *  # alias
