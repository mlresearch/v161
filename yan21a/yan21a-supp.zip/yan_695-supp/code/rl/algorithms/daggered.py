import pdb
import copy
import numpy as np
from numpy import linalg as la
import functools
import tensorflow as tf
from tensorflow import keras
from rl.core.utils.misc_utils import flatten, unflatten, timed, zipsame
from rl.core.utils.tf2_utils import ts_to_array, array_to_ts, var_assign
from rl.algorithms.algorithm import Algorithm, PolicyAgent
from rl.core.function_approximators.policies import Policy
from rl.core.online_learners import base_algorithms as balg
from rl.core.online_learners import BasicOnlineOptimizer
from rl.core.online_learners.scheduler import PowerScheduler
from rl.core.utils import logz
from rl.oracles.oracle import rlOracle

import pdb


class Helper(object):

    def __init__(self, ts_var):
        self.ts_var = ts_var
        self._var_shapes = None

    @property
    def variable(self):
        return self.flatten(self.variables)

    @variable.setter
    def variable(self, val):
        self.variables = self.unflatten(val)

    @property
    def variables(self):
        return [var.numpy() for var in self.ts_var]

    @variables.setter
    def variables(self, vals):  # vals can be a list of nd.array or tf.Tensor
        [var.assign(val) for var, val in zipsame(self.ts_var, vals)]

    @property
    def var_shapes(self):
        if self._var_shapes is None:
            self._var_shapes = [var.shape.as_list() for var in self.ts_var]
        return self._var_shapes

    # helps functions
    def flatten(self, vals):
        return flatten(vals)

    def unflatten(self, val):
        return unflatten(val, shapes=self.var_shapes)


class ImitationLearningOrale(rlOracle):
    def __init__(self, policy, ts_var, expert, loss_type, **kwargs):
        self._expert = expert
        self._policy = policy
        self._helper = Helper(ts_var)
        if loss_type == 'mse':
            self._loss_fun = keras.losses.MeanSquaredError()
        elif loss_type == 'huber':
            self._loss_fun = keras.losses.Huber(kwargs['delta'])
        self._ro = None
        self._expert_ac = None

    def update(self, ro):
        # Annotate using expert policy.
        self._ro = ro
        self._expert_ac = self._expert(ro['obs_short'], stochastic=False)

    def fun(self, x):
        self._helper.variable = x
        ac = self._policy(self.ro['obs_short'], stochastic=False)
        loss = self._loss_fun(self._expert_ac, ac).numpy()
        return loss

    def grad(self, x):
        self._helper.variable = x
        with tf.GradientTape() as tape:
            tape.watch(self._helper.ts_var)
            ts_ac = self._policy.kmodel(self.ro['obs_short'], training=True)
            ts_loss = self._loss_fun(self._expert_ac, ts_ac)
        grad = flatten(ts_to_array(tape.gradient(ts_loss, self._helper.ts_var)))
        return grad

    @property
    def ro(self):
        return self._ro


class DeterministicPolicyAgent(PolicyAgent):

    def pi(self, ob, t, done):
        return self.policy(ob, stochastic=False)

    def logp(self, obs, acs):
        return .0


class DAggered(Algorithm):

    def _get_ts_var(self, policy, last_layer_only):
        if last_layer_only:
            for layer in reversed(policy.kmodel.layers):
                if isinstance(layer, keras.layers.Dense):
                    ts_var = layer.trainable_variables
                    return ts_var
            raise ValueError('No last dense layer!')
        else:
            ts_var = policy.ts_mean_variables
        return ts_var

    def _get_last_layer_kernel_name(self):
        n_layer = len([layer for layer in self.policy.kmodel.layers if isinstance(layer, keras.layers.Dense)])
        # XXX hack
        if n_layer == 1:
            last_layer_kernel_name = 'dense/kernel:0'
        else:
            last_layer_kernel_name = 'dense_{}/kernel:0'.format(n_layer - 1)
        return last_layer_kernel_name

    def _scale_last_layer(self):
        if self._last_layer_kernel_max_norm is not None:
            last_layer_kernel_name = self._get_last_layer_kernel_name()
            for v in self._ts_var:
                if v.name == last_layer_kernel_name:
                    if la.norm(v.numpy()) > self._last_layer_kernel_max_norm:
                        scale = 1.0 / la.norm(v.numpy()) * self._last_layer_kernel_max_norm
                        v.assign(v.numpy() * scale)
                    break

    def __init__(self, policy, expert, lr=1e-3,
                 n_warm_up_itrs=None, n_pretrain_itrs=5, last_layer_only=False,
                 last_layer_kernel_max_norm=None, loss_type='mse',
                 or_kwargs=None):

        assert isinstance(policy, Policy)
        self.policy = policy
        self.expert = expert
        self._last_layer_only = last_layer_only
        self._last_layer_kernel_max_norm = last_layer_kernel_max_norm
        self._ts_var = self._get_ts_var(policy, last_layer_only)
        self._helper = Helper(self._ts_var)

        # Assign expert to policy, except some variables to be learned.
        names = [v.name for v in self._ts_var]
        for ev, pv in zipsame(expert.ts_variables, policy.ts_variables):
            if pv.name in names:
                continue
            pv.assign(ev.numpy())

        # Create online learner.
        x0 = self._helper.variable
        scheduler = PowerScheduler(lr, c=0.0)  # constant stepsize
        self.learner = BasicOnlineOptimizer(balg.Adagrad(x0, scheduler))

        # Oracle.
        or_policy = copy.deepcopy(policy)
        ts_var = self._get_ts_var(or_policy, last_layer_only)
        self.oracle = ImitationLearningOrale(or_policy, ts_var, expert, loss_type,
                                             **or_kwargs)

        # Workflow.
        self._n_pretrain_itrs = n_pretrain_itrs
        if n_warm_up_itrs is None:
            n_warm_up_itrs = float('Inf')
        self._n_warm_up_itrs = n_warm_up_itrs
        self._itr = 0

    def get_policy(self):
        return self.policy

    def agent(self, mode):
        return DeterministicPolicyAgent(self.policy)

    def pretrain(self, gen_ro):
        with timed('Pretraining'):
            for _ in range(self._n_pretrain_itrs):
                ros, _ = gen_ro(DeterministicPolicyAgent(self.expert))
                ro = self.merge(ros)
                self.oracle.update(ro)
                self.policy.update(xs=ro['obs_short'])

    def eval_policy(self, ros, agents):
        # Assume the oracle does not have state.
        ro = self.merge(ros)
        self.oracle.update(ro)
        loss = self.oracle.fun(self._helper.variable)
        logz.log_tabular('loss_eval', loss)

    def update(self, ros, agents):
        # Aggregate data
        ro = self.merge(ros)
        self._scale_last_layer()

        # Update input normalizer for whitening
        if self._itr < self._n_warm_up_itrs:
            self.policy.update(xs=ro['obs_short'])

        # Mirror descent
        with timed('Update oracle'):
            # Annotate the samples using expert
            self.oracle.update(ro)
        loss0 = self.oracle.fun(self._helper.variable)

        with timed('Compute policy gradient'):
            g = self.oracle.grad(self._helper.variable)

        with timed('Policy update'):
            self.learner.update(g)
            self._helper.variable = self.learner.x
            self._scale_last_layer()  # projected gradient

        loss1 = self.oracle.fun(self._helper.variable)

        # log
        logz.log_tabular('stepsize', self.learner.stepsize)
        logz.log_tabular('std', np.mean(np.exp(self.policy.lstd)))
        logz.log_tabular('g_norm', np.linalg.norm(g))
        logz.log_tabular('loss0', loss0)
        logz.log_tabular('loss1', loss1)
        # Save last layer kernel norm.
        last_layer_kernel_name = self._get_last_layer_kernel_name()
        for v in self._ts_var:
            if v.name == last_layer_kernel_name:
                logz.log_tabular('kernel_norm', np.linalg.norm(v.numpy()))
        self._itr += 1

    @staticmethod
    def merge(ros):
        """ Merge a list of Dataset instances. """
        return functools.reduce(lambda x, y: x + y, ros)
