# Code for a UAI 2021 Paper #

The README file for reproducing the experimental results of the paper:
Explaining Fast Improvement in Online Imitation Learning

The skeleton code of the online imitation learning algorithm can be found in following files:
scripts/daggered.py
rl/algorithms/daggered.py
scripts/daggered_ranges.py

Curve plotting is implemented in the file plot_curves.py

### Computer Infrastructure ###
Tested in Ubuntu 16.04 and Ubuntu 18.04 with python 3.5, 3.6, 3.7.

### Dependencies ###
It is required to install dartsim, pydart2, and DartEnv.

#### Install most of the requirements ####
```
pip install --upgrade -r requirements.txt
```
You may need to run
```
export PYTHONPATH="{PYTHONPATH}:[the parent folder of this repo]"
```
The current version requires also tensorflow2.
```
pip install --upgrade tensorflow
```

#### Install DART ####
The Ubuntu package is too new for PyDart2, so we install an older version of DART from source.

Firstly, install the requirements following the instructions of Install DART from source at https://dartsim.github.io/install_dart_on_ubuntu.html. 
Next we compile and install DART manually, because PyDart2 only supports DART before 6.8.
```
git clone git://github.com/dartsim/dart.git
cd dart
git checkout tags/v6.7.2
mkdir build
cd build
cmake ..
make -j4
sudo make install
```
Sometimes the library may need to be linked manually through
```
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/lib:/usr/lib:/usr/local/lib
```

#### Install PyDart2 ####
Installing PyDart2 through pip does not work, so we install it from source.
```
git clone https://github.com/sehoonha/pydart2.git
cd pydart2
python setup.py build build_ext
python setup.py develop
```

#### Install DartEnv ####
```
git clone https://github.com/DartEnv/dart-env.git
cd dartenv
pip install -e .[dart]
```

Then we need to make several small modifications:
1. Edit the file `dart-env/gym/envs/dart/dart_env.py` by adding
```python
    @property
    def state(self):
        return self.state_vector()
```
to the end of the file, and adding `return self._get_obs()` to the end of the function `set_state_vector()`.

2. Edit the file `dart-env/gym/envs/dart/cart_pole.py` by changing `disableViewer=False` to `disableViewer=True` in the `__init__()` function to disable visualization.



### Reproduce Results ###
The experimental results in the paper are in the `log_daggered_last_layer` and `log_daggered_full_nn` folders. The curves can be plotted by executing the command. THe following commands should generate the files plots.pdf under folders `log_daggered_last_layer` and `log_daggered_full_nn`.
>> python plot_curves.py log_daggered_last_layer
>> python plot_curves.py log_daggered_full_nn

To reproduce the results completely, there are three steps:
1. To train the experts:
>> python scripts/pg.py

2. To train the learner through online IL:
>> python batch_run.py daggered -c cp -r lr
This will run the online IL algorithm 4 (random seeds) x 8 (configurations) = 32 times. And each run has 500 rounds. 
Then the results will be written to the `log_daggered` folder. Folders that end with `_T` are the results of training the weights of the last layer and folders that end with `_F` are the results of training the full network. Then we can move the folders that end with `_T` to `log_daggered_last_layer` and folders  that end with `_F` to `log_daggered_full_nn`.


3. To plot the results:
>> python plot_curves.py log_daggered_last_layer
>> python plot_curves.py log_daggered_full_nn

