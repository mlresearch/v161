import argparse
import tensorflow as tf
import numpy as np
from scripts.utils import parser as ps
from rl import experimenter as Exp
from rl.algorithms import DAggered
from rl.core.function_approximators.policies.tf2_policies import RobustKerasMLPGassian
from rl.core.function_approximators.supervised_learners import SuperRobustKerasMLP


def main(c):
    # Setup logz and save c
    ps.configure_log(c)

    # Create mdp and fix randomness
    mdp = ps.setup_mdp(c['mdp'], c['seed'])

    # Create learnable objects
    ob_shape = mdp.ob_shape
    ac_shape = mdp.ac_shape
    if mdp.use_time_info:
        ob_shape = (np.prod(ob_shape) + 1,)

    # define expert
    expert = RobustKerasMLPGassian(ob_shape, ac_shape, name='policy',
                                   init_lstd=c['init_lstd'],
                                   units=c['policy_units'])
    expert.restore(c['expert_path'], name='policy_best')
    expert.name = 'expert_policy'

    # define learner policy
    policy = RobustKerasMLPGassian(ob_shape, ac_shape, name='policy',
                                   init_lstd=c['init_lstd'],
                                   units=c['policy_units'],
                                   last_layer_scale=c['policy_last_layer_scale'])
    policy_init = policy.variable
    # Make sure policy is the same as expert except on some variables.
    policy.restore(c['expert_path'], name='policy_best')
    # XXX HACK
    # policy.variable = policy_init
    policy.name = 'learner_policy'

    # Create algorithm
    alg = DAggered(policy, expert, **c['algorithm'])

    # Let's do some experiments!
    exp = Exp.Experimenter(alg, mdp, ro_kwargs=c['experimenter']['rollout_kwargs'],
                           ro_kwargs_test=c['experimenter']['rollout_kwargs_test'])
    exp.run(**c['experimenter']['run_kwargs'])


config_cp = {
    'top_log_dir': 'log_daggered',
    'exp_name': 'cp',
    'seed': 0,
    'mdp': {
        'envid': 'DartCartPole-v1',
        'horizon': 1000,  # the max length of rollouts in training
        'gamma': 1.0,
        'n_processes': 1,
    },
    'expert_path': './log_pg/cp/10/saved_policies',
    'experimenter': {
        'run_kwargs': {
            'n_itrs': 500,
            'pretrain': False,
            'final_eval': False,
            'save_freq': None,
            'eval_freq': 1,
        },
        'rollout_kwargs': {
            'min_n_samples': 1000,
            'max_n_rollouts': None,
        },
        'rollout_kwargs_test': {
            'min_n_samples': 5000,
            'max_n_rollouts': None,
        },
    },
    'algorithm': {
        'lr': 0.004,
        'n_pretrain_itrs': 0,
        'n_warm_up_itrs': 0,  # fix the policy normalizer.
        # 'last_layer_only': True,
        'last_layer_only': False,
        'loss_type': 'huber',
        'last_layer_kernel_max_norm': None,
        'or_kwargs': {
            'delta': 0.05,
        }
    },
    'policy_units': (64,),
    'init_lstd': -1,
    'policy_last_layer_scale': 0.001,
}

if __name__ == '__main__':
    main(config_cp)
