from scripts import ranges as R

range_common = [
    [['seed'], [x * 100 for x in range(4)]],
]

range_lr = [
    [['algorithm', 'lr'], [0.01]],
    [['algorithm', 'last_layer_kernel_max_norm'], [None, 0.1, 0.12, 0.15]],
    [['algorithm', 'last_layer_only'], [True, False]],
]
range_lr = R.merge_ranges(range_common, range_lr)
