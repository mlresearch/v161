from scripts import ranges as R

range_common = [
    [['seed'], [x * 100 for x in range(4)]],
]

range_lambd = [
    [['algorithm', 'lambd'], [0, 0.1, 0.5, 0.9, 1.]],
]
range_lambd = R.merge_ranges(range_common, range_lambd)

range_std = [
    [['policy_last_layer_scale'], [0.01, 0.1, 1.0]],
]
range_std = R.merge_ranges(range_common, range_std)
