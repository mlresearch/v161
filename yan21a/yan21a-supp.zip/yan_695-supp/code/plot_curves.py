import matplotlib as mpl
import pdb
import os
import argparse
import numpy as np
import matplotlib.pyplot as plt
import matplotlib


def read_attr(csv_path, attr):
    def get_items(line):
        return line.rstrip('\n').split('\t')
    iters = []
    is_continuous = True
    has_started = False
    with open(csv_path) as f:
        lines = f.readlines()
        if len(lines) == 0:
            return None, None, None
        attrs = get_items(lines[0])
        if attr not in attrs:
            return None, None, None
        idx = attrs.index(attr)
        vals = []
        for i in range(1, len(lines)):
            d = get_items(lines[i])
            if d[idx] != '':
                vals.append(d[idx])
                iters.append(i - 1)
                has_started = True
            elif has_started:  # has holes in the data
                is_continuous = False
    return np.array(vals, dtype=np.float64), iters, is_continuous


def configure_plot(fontsize, usetex):
    fontsize = fontsize
    matplotlib.rc("text", usetex=usetex)
    matplotlib.rcParams['axes.linewidth'] = 0.1
    matplotlib.rcParams["figure.figsize"] = 8, 8
    matplotlib.rc("xtick", labelsize=fontsize)
    matplotlib.rc("ytick", labelsize=fontsize)


def plot_curves(save_folder, data_dict, mode=None):

    linewidth = 3
    markersize = 10
    ticks_fontsize = 30
    fontsize = 19
    legend_fontsize = 28
    label_fontsize = 40
    usetex = True

    pdf_name = 'plots'
    norms = [0.1, 0.12, 0.15, None]
    line_style = [':', '-.', '--', '-']

    configure_plot(fontsize, usetex)
    for idx, (name, data) in enumerate(data_dict.items()):
        itrs = np.arange(1, len(data['mean']) + 1)
        # Take log.
        itrs = np.log(itrs)
        norm = norms[idx]
        label_str = 'no constraint' if norm is None else r'last layer norm $< {:.2f}$'.format(norm)
        plt.plot(itrs, data['mean'], line_style[idx], label=label_str,
                 markersize=markersize, linewidth=linewidth)
        plt.fill_between(itrs, data['p10'], data['p90'], alpha=0.25)
    plt.xlabel(r'$\ln(N)$', fontsize=label_fontsize)
    plt.title(r'$\ln(\frac{1}{N} \sum_{n=1}^N l_n(\theta_n))$', fontsize=label_fontsize)
    plt.xticks(fontsize=ticks_fontsize)
    plt.yticks(fontsize=ticks_fontsize)
    plt.grid()
    legend = plt.legend(fontsize=legend_fontsize, frameon=False)
    plt.autoscale(enable=True, tight=True)
    plt.tight_layout()
    for line in legend.get_lines():
        line.set_linewidth(5.0)
    output_path = os.path.join(save_folder, pdf_name + '.pdf')
    plt.savefig(output_path)
    plt.clf()


def main(exp):
    attr = 'loss_eval'
    seeds = [0, 100, 200, 300]  # 4 seeds
    logdir = os.path.join('.', exp)
    subdirs = sorted(os.listdir(logdir))
    subdirs = [d for d in subdirs if d[0] != '.']  # filter out weird things

    data_dict = {}
    for sd in subdirs:
        print('============================================================')
        print(sd)

        d = os.path.join(logdir, sd)
        if not os.path.isdir(d):
            continue
        all_data = []
        for seed in seeds:
            path = os.path.join(d, str(seed), 'log.txt')
            data, _, is_continuous = read_attr(path, attr)
            assert is_continuous
            data = np.cumsum(data) / np.arange(1, len(data) + 1)
            all_data.append(data)
        all_data = np.vstack(all_data)
        # Take log.
        all_data = np.log(all_data)
        p10, p50, p90 = np.percentile(all_data, [10, 50, 90], axis=0)
        data = {'p10': p10, 'p50': p50, 'p90': p90, 'mean': np.mean(all_data, axis=0)}
        data_dict[sd] = data

    plot_curves(logdir, data_dict)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('exp', type=str, default='.')
    args = parser.parse_args()
    main(args.exp)
