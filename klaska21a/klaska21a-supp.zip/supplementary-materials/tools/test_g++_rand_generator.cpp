#include <stdlib.h>

int main()
{
	if(rand() != 1804289383) return 1;
	if(rand() != 846930886) return 2;
	if(rand() != 1681692777) return 3;
	return 0;
}
