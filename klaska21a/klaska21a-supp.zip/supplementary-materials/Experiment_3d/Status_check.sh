#! /bin/bash


for i in Building_m_*; do 
    echo $i:; \
    ls $i/*out | wc -l; \
    #grep Trial.*Value -c $i/*.out; \
    #wc -l $i/*.time; \
    #ls -l -t $i/*out |head -1 | sed "s/^[^ ]* [^ ]* [^ ]* [^ ]* [^ ]* //"; \
    echo ;
done
