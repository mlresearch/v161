
# Supplementary materials


Experiment_1/
   - Comparison to Baseline described in Section 5.1
   - for more detail see ./Experiment_1/README.md

Experiment_2/
   - Real-World Patrolling Graph described in Section 5.2
   - for more detail see ./Experiment_2/README.md

Experiment_3a/
   - Patrolling an Office Building with one floor
     described in Section 5.3 (Table 2)
   - for more detail see ./Experiment_3a/README.md

Experiment_3b/
   - Patrolling an Office Building with two floors
     described in Section 5.3 (Table 2)
   - for more detail see ./Experiment_3b/README.md

Experiment_3c/
   - Patrolling an Office Building with three floors
     described in Section 5.3 (Table 2)
   - for more detail see ./Experiment_3c/README.md

Experiment_3d/
   - Patrolling an Office Building with one floor
     described in Section 5.3 (Table 3)
   - for more detail see ./Experiment_3d/README.md


tools/
   - implementations of the presented patrolling algorithms
   - Makefile and other supplementary script
   - for more detail see ./tools/README.md

README.md
   - this file

SW_compatibility_and_versions.txt
   - self-explanatory
