#! /bin/bash

echo "Running..."

for i in Mont_m_*; do
    cd $i; \
    echo $i; \
    ./run.sh; \
    cd ..; \
done

echo "done"
